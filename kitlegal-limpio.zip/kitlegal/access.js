const form = document.querySelector("#access-form");
const emailInput = document.querySelector("#access-email");
const errorMessage = document.querySelector("#access-error");
const submitButton = form?.querySelector(".access-submit");

function showError(message) {
  errorMessage.textContent = message;
  errorMessage.hidden = false;
}

async function checkExistingSession() {
  try {
    const response = await fetch("/api/kit-access/status", {
      credentials: "same-origin",
      headers: { Accept: "application/json" },
    });
    if (!response.ok) throw new Error("No se pudo comprobar el acceso.");
    const status = await response.json();
    if (status.ok) window.location.replace("/");
  } catch {
    showError("No se pudo comprobar el acceso con el servidor. Inténtalo de nuevo.");
  }
}

form?.addEventListener("submit", async event => {
  event.preventDefault();
  if (!emailInput.checkValidity()) {
    showError("Introduce un correo válido para acceder al kit.");
    emailInput.focus();
    return;
  }

  errorMessage.hidden = true;
  submitButton.disabled = true;
  submitButton.setAttribute("aria-busy", "true");

  try {
    const response = await fetch("/api/kit-access/validate", {
      method: "POST",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        email: emailInput.value.trim(),
      }),
    });
    const result = await response.json();
    if (!response.ok || result.ok !== true) {
      showError(result.message || "El correo no coincide con un acceso activo.");
      emailInput.select();
      return;
    }

    submitButton.classList.add("is-sending");
    window.setTimeout(() => window.location.replace("/"), 650);
  } catch {
    showError("No se pudo contactar con el servidor. Revisa tu conexión e inténtalo de nuevo.");
  } finally {
    if (!submitButton.classList.contains("is-sending")) {
      submitButton.disabled = false;
      submitButton.removeAttribute("aria-busy");
    }
  }
});

checkExistingSession();
