const stages = [
  {
    step: "BASE 01",
    title: "Antes de aceptar",
    description:
      "Ese momento en el que la marca te escribe y necesitas entender bien de qué va todo antes de comprometerte.",
    items: [
      "Cómo responderles al inicio.",
      "Qué preguntar sobre el brief, entregables, fechas y presupuesto.",
      "Revisiones, permisos y usos.",
      "Todo lo que debes confirmar antes de darles el sí.",
    ],
    tip: "Primero entiende bien la oportunidad; ya luego decides si te conviene.",
    files: [
      {
        label: "Guion de respuesta inicial para una marca",
        href: "descargas/01-script-respuesta-marca.docx",
      },
    ],
  },
  {
    step: "BASE 02",
    title: "Antes de grabar",
    description:
      "Ya sabes de qué va el proyecto. Ahora deja por escrito lo importante antes de grabar, para que las dos partes estén en la misma página.",
    items: [
      "Producto, objetivo, entregables y formato.",
      "Precio, fechas y revisiones.",
      "Anticipo, saldo y permisos de uso.",
      "Una sola vía de confirmación: Word formal o mensaje breve.",
    ],
    tip: "Primero organiza tu control interno; después elige la vía más cómoda para confirmar el acuerdo.",
    files: [
      {
        label: "Control interno — Confirmación antes de grabar",
        href: "descargas/02-confirmacion-antes-de-grabar.md",
      },
      {
        label: "Confirmación formal en Word",
        href: "descargas/02-confirmacion-de-acuerdos.docx",
      },
      {
        label: "Confirmación breve — WhatsApp, correo o DM",
        href: "descargas/02-confirmacion-acuerdos-completa.md",
      },
      {
        label: "Brief y checklist de alcance",
        href: "descargas/02-brief-y-checklist-entrega.docx",
      },
      {
        label: "Términos de trabajo y alcance",
        href: "descargas/02-terminos-facturacion-pago.docx",
      },
      {
        label: "Plantilla de brief técnico y comercial",
        href: "descargas/02-brief-tecnico-comercial.md",
      },
    ],
  },
  {
    step: "BASE 03",
    title: "Antes de entregar",
    description:
      "Estás por enviar el contenido. Tómate un momento para comprobar que lo que entregas coincide con lo que acordaron.",
    items: [
      "Contrato marco UGC.",
      "Servicios, pagos, entregables y revisiones.",
      "Licencia de uso y confidencialidad.",
      "Checklist técnico y de calidad antes de entregar.",
    ],
    tip: "Antes de enviar la versión final, revisa el documento y también el archivo. Tu yo de mañana te lo agradecerá.",
    files: [
      {
        label: "Contrato marco UGC — 20 cláusulas",
        href: "descargas/03-contrato-marco-ugc.docx",
      },
      {
        label: "Checklist de entrega y cobro",
        href: "descargas/03-checklist-entrega-cobro.md",
      },
      {
        label: "Checklist operativo para marketing y agencias",
        href: "descargas/03-checklist-marketing-agencias.md",
      },
      {
        label: "Autorización de imagen, voz e identidad",
        href: "descargas/03-release-derechos-imagen-voz.md",
      },
    ],
  },
  {
    step: "BASE 04",
    title: "Antes de autorizar anuncios",
    description:
      "Quieren usar tu contenido en anuncios. Antes de dar el sí, define bien el alcance de ese permiso y cuánto vale para ti.",
    items: [
      "Plataformas, cuenta publicitaria y finalidad.",
      "Duración, territorio y tarifa por uso publicitario.",
      "Meta Ads, TikTok Ads, Spark Ads y Whitelisting.",
      "Renovaciones, variaciones y retiro de accesos.",
    ],
    tip: "Crear el contenido y autorizar que se convierta en anuncio son decisiones distintas. Las dos se negocian.",
    files: [
      {
        label: "Anexo 04A — Licencia de Paid Media",
        href: "descargas/04A-anexo-licencia-paid-media.docx",
      },
      {
        label: "Anexo 04B — Whitelisting y Spark Ads",
        href: "descargas/04B-anexo-whitelisting-spark-ads.docx",
      },
      {
        label: "Anexo 04C — Meta Ads y cuentas publicitarias",
        href: "descargas/04C-anexo-meta-ads-cuentas-publicitarias.docx",
      },
    ],
  },
  {
    step: "BASE 05",
    title: "Si ocurre un problema",
    description:
      "Si un pago se retrasa, cambia el alcance o algo se sale de lo acordado, vuelve a lo que dejaste por escrito.",
    items: [
      "Seguimiento profesional del pago.",
      "Solicitud de una fecha concreta.",
      "Carta de reclamo por incumplimiento.",
      "Registro claro de lo ocurrido.",
    ],
    tip: "Cuando la conversación se complica, tener tus acuerdos a mano te devuelve claridad y calma.",
    files: [
      {
        label: "Carta de cobro por saldo pendiente",
        href: "descargas/05-carta-cobro-saldo-pendiente.docx",
      },
      {
        label: "Carta de reclamo por incumplimiento",
        href: "descargas/05-carta-incumplimiento-subsanacion.docx",
      },
      {
        label: "Guiones para hacer seguimiento de pago",
        href: "descargas/05-scripts-seguimiento-pago.docx",
      },
    ],
  },
];
const accessGate = document.querySelector("#access-gate");
const accessForm = document.querySelector("#access-form");
const accessEmailInput = document.querySelector("#access-email");
const accessCodeInput = document.querySelector("#access-code");
const accessError = document.querySelector("#access-error");
const accessButton = accessForm?.querySelector(".access-submit");
const siteHeader = document.querySelector(".site-header");
const siteMenuToggle = document.querySelector(".site-menu-toggle");
const siteNavigation = document.querySelector("#site-navigation");

function closeSiteMenu({ restoreFocus = false } = {}) {
  if (!siteMenuToggle || !siteNavigation) return;
  siteHeader.classList.remove("menu-open");
  siteNavigation.hidden = true;
  siteNavigation.querySelectorAll("details").forEach(details => {
    details.open = false;
  });
  siteMenuToggle.setAttribute("aria-expanded", "false");
  siteMenuToggle.setAttribute("aria-label", "Abrir menú");
  if (restoreFocus) siteMenuToggle.focus();
}

siteMenuToggle?.addEventListener("click", () => {
  const isOpen = siteMenuToggle.getAttribute("aria-expanded") === "true";
  if (isOpen) {
    closeSiteMenu();
    return;
  }
  siteNavigation.hidden = false;
  siteHeader.classList.add("menu-open");
  siteMenuToggle.setAttribute("aria-expanded", "true");
  siteMenuToggle.setAttribute("aria-label", "Cerrar menú");
  siteNavigation.querySelector("a")?.focus();
});
siteNavigation?.addEventListener("click", event => {
  if (event.target instanceof Element && event.target.closest("a"))
    closeSiteMenu();
});
document.addEventListener("pointerdown", event => {
  if (siteHeader && !siteHeader.contains(event.target)) closeSiteMenu();
});
document.addEventListener("keydown", event => {
  if (
    event.key === "Escape" &&
    siteMenuToggle?.getAttribute("aria-expanded") === "true"
  ) {
    closeSiteMenu({ restoreFocus: true });
  }
});
document.addEventListener("keydown", event => {
  if (!accessGate || accessGate.hidden || event.key !== "Tab") return;
  const focusable = [
    ...accessGate.querySelectorAll(
      'a[href],button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex]:not([tabindex="-1"])'
    ),
  ];
  const first = focusable[0];
  const last = focusable[focusable.length - 1];
  if (!first || !last) {
    event.preventDefault();
    return;
  }
  if (
    event.shiftKey &&
    (document.activeElement === first ||
      !accessGate.contains(document.activeElement))
  ) {
    event.preventDefault();
    last.focus();
  } else if (
    !event.shiftKey &&
    (document.activeElement === last ||
      !accessGate.contains(document.activeElement))
  ) {
    event.preventDefault();
    first.focus();
  }
});

async function validateAccessRequest(email, code) {
  try {
    const response = await fetch("/api/kit-access/validate", {
      method: "POST",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({ email, code }),
    });
    const data = await response.json();
    return response.ok && data?.ok === true
      ? { ok: true, email: data.email }
      : {
          ok: false,
          message: data?.message || "No pudimos validar tu acceso.",
        };
  } catch (error) {
    return {
      ok: false,
      message:
        "No se pudo contactar con la validación del kit. Inténtalo de nuevo.",
    };
  }
}

async function checkAccessStatus() {
  try {
    const response = await fetch("/api/kit-access/status", {
      credentials: "same-origin",
    });
    const data = await response.json();
    if (response.ok && data?.ok) {
      unlockKit(data.email || accessEmailInput?.value || "");
      return true;
    }
    return false;
  } catch (error) {
    return false;
  }
}

function unlockKit(email = "") {
  if (!accessGate) return;
  accessGate.hidden = true;
  document.body.classList.remove("is-locked");
}

checkAccessStatus().then(hasAccess => {
  if (!hasAccess && accessGate && !accessGate.hidden) accessEmailInput?.focus();
});

const revealItems = document.querySelectorAll(
  "[data-reveal], .document-map-heading, .clarity-copy, .clarity-cards, .includes-heading, .document-stack, .legal-framework-heading, .legal-framework-grid, .advice-heading, .advice-grid, .faq-heading, .faq-list"
);
const reduceMotion = window.matchMedia(
  "(prefers-reduced-motion: reduce)"
).matches;

// La cinta se mueve continuamente, pero también admite arrastre directo con ratón o dedo.
const dragNote = document.querySelector("[data-drag-scroll]");
const dragWindow = dragNote?.querySelector(".intro-note-window");
const dragTrack = dragNote?.querySelector(".intro-note-track");
if (dragTrack && dragTrack.children.length === 1) {
  const duplicate = dragTrack.firstElementChild?.cloneNode(true);
  if (duplicate instanceof HTMLElement) {
    duplicate.setAttribute("aria-hidden", "true");
    dragTrack.append(duplicate);
  }
}
if (dragNote && dragWindow && dragTrack && !reduceMotion) {
  let pointerId = null;
  let startX = 0;
  let startTransform = 0;
  let moved = false;
  const readTranslateX = () => {
    const transform = window.getComputedStyle(dragTrack).transform;
    if (!transform || transform === "none") return 0;
    try {
      return new DOMMatrix(transform).m41;
    } catch {
      return 0;
    }
  };
  dragWindow.addEventListener("pointerdown", event => {
    pointerId = event.pointerId;
    startX = event.clientX;
    startTransform = readTranslateX();
    moved = false;
    dragNote.classList.add("is-dragging");
    dragWindow.setPointerCapture?.(pointerId);
    dragTrack.style.transform = `translate3d(${startTransform}px, 0, 0)`;
  });
  dragWindow.addEventListener("pointermove", event => {
    if (event.pointerId !== pointerId) return;
    const delta = event.clientX - startX;
    if (Math.abs(delta) > 4) moved = true;
    dragTrack.style.transform = `translate3d(${startTransform + delta}px, 0, 0)`;
  });
  const finishDrag = event => {
    if (event.pointerId !== pointerId) return;
    const delta = event.clientX - startX;
    const currentShift =
      parseFloat(dragTrack.style.getPropertyValue("--drag-shift")) || 0;
    dragTrack.style.setProperty("--drag-shift", `${currentShift + delta}px`);
    dragTrack.style.removeProperty("transform");
    dragNote.classList.remove("is-dragging");
    pointerId = null;
  };
  dragWindow.addEventListener("pointerup", finishDrag);
  dragWindow.addEventListener("pointercancel", finishDrag);
  dragWindow.addEventListener("lostpointercapture", () => {
    pointerId = null;
  });
}
const studyMoment = document.querySelector(".study-moment");
const studyReading = studyMoment?.querySelector(".study-reading");
const studySteps = [
  ...(studyReading?.querySelectorAll("[data-study-step]") ?? []),
];
const studyVisual = studyMoment?.querySelector(".study-visual");
if (
  studyMoment &&
  studyReading &&
  studyVisual &&
  studySteps.length &&
  !reduceMotion
) {
  let studyFrame = 0;
  const updateStudyProgress = () => {
    studyFrame = 0;
    const bounds = studyMoment.getBoundingClientRect();
    const progress = Math.max(
      0,
      Math.min(
        1,
        (window.innerHeight - bounds.top) / (window.innerHeight + bounds.height)
      )
    );
    const activeStep = Math.min(
      studySteps.length - 1,
      Math.floor(progress * studySteps.length)
    );
    studyReading.style.setProperty("--study-progress", String(progress));
    studyVisual.style.setProperty("--study-tilt", `${1.5 - progress * 3}deg`);
    studySteps.forEach((step, index) => {
      if (index === activeStep) step.setAttribute("aria-current", "step");
      else step.removeAttribute("aria-current");
    });
  };
  const scheduleStudyProgress = () => {
    if (!studyFrame)
      studyFrame = window.requestAnimationFrame(updateStudyProgress);
  };
  window.addEventListener("scroll", scheduleStudyProgress, { passive: true });
  window.addEventListener("resize", scheduleStudyProgress);
  scheduleStudyProgress();
}
const typewriter = document.querySelector("[data-typewriter]");
const typewriterText = typewriter?.textContent || "";
if (!reduceMotion) {
  window.requestAnimationFrame(() =>
    document.body.classList.add("header-intro-ready")
  );
} else {
  document.body.classList.add("header-intro-ready");
}
function startTypewriter() {
  if (!typewriter || typewriter.dataset.started || reduceMotion) return;
  typewriter.dataset.started = "true";
  typewriter.textContent = "";
  typewriter.classList.add("is-typing");
  let index = 0;
  const typeNextCharacter = () => {
    if (!typewriter) return;
    index += 1;
    typewriter.textContent = typewriterText.slice(0, index);
    if (index < typewriterText.length) {
      window.setTimeout(typeNextCharacter, 12);
    } else {
      typewriter.classList.remove("is-typing");
      typewriter.classList.add("typing-complete");
    }
  };
  typeNextCharacter();
}
if (reduceMotion) {
  revealItems.forEach(item => item.classList.add("visible"));
} else if ("IntersectionObserver" in window) {
  const revealObserver = new IntersectionObserver(
    entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          if (entry.target.classList.contains("hero-copy")) startTypewriter();
          revealObserver.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.18, rootMargin: "0px 0px -40px 0px" }
  );

  revealItems.forEach(item => revealObserver.observe(item));
} else {
  revealItems.forEach(item => item.classList.add("visible"));
  startTypewriter();
}

let accessAudioContext = null;
function primeAccessAudio() {
  const AudioContext = window.AudioContext || window.webkitAudioContext;
  if (!AudioContext) return;
  if (!accessAudioContext) accessAudioContext = new AudioContext();
  if (accessAudioContext.state === "suspended")
    accessAudioContext.resume().catch(() => {});
}
function playAccessTone(startFrequency, endFrequency, duration = 0.07) {
  if (!accessAudioContext || accessAudioContext.state !== "running") return;
  const oscillator = accessAudioContext.createOscillator();
  const gain = accessAudioContext.createGain();
  const now = accessAudioContext.currentTime;
  oscillator.type = "sine";
  oscillator.frequency.setValueAtTime(startFrequency, now);
  oscillator.frequency.exponentialRampToValueAtTime(
    endFrequency,
    now + duration
  );
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(0.018, now + 0.012);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
  oscillator.connect(gain).connect(accessAudioContext.destination);
  oscillator.start(now);
  oscillator.stop(now + duration + 0.01);
}
if (accessButton) {
  accessButton.addEventListener("pointerdown", primeAccessAudio, {
    passive: true,
  });
  accessButton.addEventListener("keydown", primeAccessAudio);
  accessButton.addEventListener("pointerenter", () => playAccessTone(560, 680));
}

function showAccessError(
  message,
  fields = [accessEmailInput, accessCodeInput]
) {
  if (!accessError) return;
  accessError.hidden = false;
  accessError.textContent = message;
  [accessEmailInput, accessCodeInput].forEach(input => {
    if (!input) return;
    if (fields.includes(input)) {
      input.setAttribute("aria-invalid", "true");
      input.setAttribute("aria-describedby", accessError.id);
    } else {
      input.removeAttribute("aria-invalid");
      input.removeAttribute("aria-describedby");
    }
  });
}

if (accessForm) {
  [accessEmailInput, accessCodeInput].forEach(input =>
    input?.addEventListener("input", () => {
      accessError.hidden = true;
      [accessEmailInput, accessCodeInput].forEach(field => {
        field?.removeAttribute("aria-invalid");
        field?.removeAttribute("aria-describedby");
      });
    })
  );
  accessForm.addEventListener("submit", async event => {
    event.preventDefault();
    const email = accessEmailInput?.value.trim() || "";
    const code = accessCodeInput?.value.trim() || "";

    if (!email || !accessEmailInput?.checkValidity()) {
      showAccessError("Introduce un correo válido para acceder al kit.", [
        accessEmailInput,
      ]);
      accessEmailInput?.select();
      return;
    }

    const validation = await validateAccessRequest(email, code);
    if (validation.ok) {
      accessError.hidden = true;
      primeAccessAudio();
      playAccessTone(420, 760, 0.11);
      accessButton.classList.add("is-sending");
      accessButton.disabled = true;
      accessButton.setAttribute("aria-busy", "true");
      window.setTimeout(() => unlockKit(validation.email), 1100);
      return;
    }

    showAccessError(validation.message);
    const focusTarget = accessEmailInput;
    focusTarget?.select();
  });
}

if (accessGate && accessGate.hidden !== true)
  document.body.classList.add("is-locked");
const filePreviews = {
  "descargas/01-script-respuesta-marca.docx":
    "Script inicial para responder a una marca y pedir la información mínima sobre brief, entregables, fechas, presupuesto, revisiones, permisos y usos previstos.",
  "descargas/02-terminos-facturacion-pago.docx":
    "Revisión de alcance, entregables, precio, fechas, revisiones, anticipo y condiciones de facturación antes de grabar.",
  "descargas/02-confirmacion-antes-de-grabar.md":
    "Control interno de la creadora para revisar producto, objetivo, alcance, precio, revisiones y permisos antes de grabar.",
  "descargas/02-confirmacion-de-acuerdos.docx":
    "Versión Word formal editable de la Confirmación antes de grabar. Elige esta opción o la confirmación express; no ambas.",
  "descargas/02-brief-y-checklist-entrega.docx":
    "Checklist para ordenar brief, formato, fechas, entregables, revisiones y requisitos de entrega.",
  "descargas/02-brief-tecnico-comercial.md":
    "Plantilla de brief con objetivo, público, mensaje, tono, guion, entregables, especificaciones, calendario, logística, aprobación, presupuesto y derechos de uso.",
  "descargas/02-confirmacion-acuerdos-completa.md":
    "Confirmación express para WhatsApp, correo o DM. Completa los campos y pide que la marca responda “Acepto estos términos”. Elige esta opción o el Word formal; no ambos.",
  "descargas/03-contrato-marco-ugc.docx":
    "Contrato marco con servicios, pagos, entregables, revisiones, licencia de uso, confidencialidad y condiciones generales.",
  "descargas/03-checklist-entrega-cobro.md":
    "Checklist operativo para revisar el archivo final, la entrega, la factura y el cobro pendiente.",
  "descargas/03-checklist-marketing-agencias.md":
    "Checklist por fases para marketing y agencias: brief, selección, producto, producción, aprobación, publicación, medición, versiones, derechos y vencimientos.",
  "descargas/03-release-derechos-imagen-voz.md":
    "Release de imagen, voz e identidad con plataformas, territorio, duración, Paid Media, ediciones, compensación, límites y aceptación.",
  "descargas/04A-anexo-licencia-paid-media.docx":
    "Licencia de Paid Media con alcance, plataformas, territorio, duración, canon y renovación.",
  "descargas/04C-anexo-meta-ads-cuentas-publicitarias.docx":
    "Anexo para delimitar Paid Media y Meta Ads: cuentas, plataformas, territorio, vigencia, tarifas, renovaciones y apagado.",
  "descargas/04B-anexo-whitelisting-spark-ads.docx":
    "Anexo para whitelisting, Partnership Ads y Spark Ads: accesos, control, aprobaciones, variaciones y desactivación.",
  "descargas/05-carta-cobro-saldo-pendiente.docx":
    "Carta para solicitar formalmente una fecha de pago y dejar constancia de un saldo pendiente.",
  "descargas/05-carta-incumplimiento-subsanacion.docx":
    "Carta para documentar un incumplimiento y solicitar una subsanación dentro de un plazo definido.",
  "descargas/05-scripts-seguimiento-pago.docx":
    "Scripts de seguimiento profesional para reclamar pagos sin perder claridad ni registro de la conversación.",
};
const modal = document.querySelector("#stage-modal");
const previewModal = document.querySelector("#preview-modal");
const previewTitle = document.querySelector("#preview-title");
const previewDescription = document.querySelector("#preview-description");
const previewPurpose = document.querySelector("#preview-purpose");
const previewWhen = document.querySelector("#preview-when");
const previewFields = document.querySelector("#preview-fields");
const previewReview = document.querySelector("#preview-review");
const previewDownload = document.querySelector("#preview-download");
const previewDownloadStatus = document.createElement("p");
previewDownloadStatus.id = "preview-download-status";
previewDownloadStatus.className = "copy-fields-status";
previewDownloadStatus.setAttribute("role", "status");
previewDownloadStatus.setAttribute("aria-live", "polite");
document.querySelector(".preview-actions").before(previewDownloadStatus);
const previewBack = document.querySelector("#preview-back");
const title = document.querySelector("#modal-title");
const step = document.querySelector("#modal-step");
const description = document.querySelector("#modal-description");
const items = document.querySelector("#modal-items");
const tip = document.querySelector("#modal-tip-text");
const downloadList = document.querySelector("#download-list");
const progressCount = document.querySelector("#progress-count");
const progressBar = document.querySelector("#progress-bar");
const progressDetail = document.querySelector("#progress-detail");
const pathway = document.querySelector(".pathway");
const globalProgressReset = document.querySelector("#global-progress-reset");
const documentProgressLabel = document.querySelector(
  "#document-progress-label"
);
const documentProgressBar = document.querySelector("#document-progress-bar");
const nextStepTitle = document.querySelector("#next-step-title");
const nextStepButton = document.querySelector("#next-step-button");
const nextStepButtonLabel = nextStepButton.querySelector("span");
const introNote = document.querySelector(".intro-note");
const introNoteMotionControl = document.querySelector(
  ".intro-note-motion-control"
);
const downloadButton = document.querySelector(".download-button");
const stagePaidAlert = document.querySelector("#stage-paid-alert");
const stageFourWorkspace = document.querySelector("#stage-four-workspace");
const celebration = document.querySelector("#celebration");
const celebrationClose = document.querySelector("#celebration-close");
const copyFieldsButton = document.querySelector("#copy-legal-fields");
const copyFieldsStatus = document.querySelector("#copy-fields-status");
const exportWordButton = document.querySelector("#export-legal-word");
const exportPdfButton = document.querySelector("#export-legal-pdf");
const clearLegalButton = document.querySelector("#clear-legal-fields");
const exportChecklistButton = document.querySelector("#export-checklist");
const legalFormProgress = document.querySelector("#legal-form-progress");
const legalFormProgressBar = document.querySelector("#legal-form-progress-bar");
const legalFormAlert = document.querySelector("#legal-form-alert");
const legalForm = document.querySelector("#legal-fields-form");
const legalPreview = document.querySelector("#legal-fields-preview");
const progressKey = "kit-legal-ugc-progress-v2";
const legalFieldsKey = "kit-legal-ugc-legal-fields-v1";
const legalFieldLabels = [
  ["ley", "[LEY APLICABLE]"],
  ["jurisdiccion", "[JURISDICCIÓN]"],
  ["territorio", "[TERRITORIO]"],
  ["plataformas", "[PLATAFORMAS]"],
  ["cuenta", "[CUENTA PUBLICITARIA]"],
  ["inicio", "[FECHA DE INICIO]"],
  ["vencimiento", "[FECHA DE VENCIMIENTO]"],
  ["paidMedia", "[TARIFA DE PAID MEDIA]"],
  ["renovacion", "[TARIFA DE RENOVACIÓN]"],
];
let progress = {};
try {
  progress = JSON.parse(localStorage.getItem(progressKey) || "{}");
} catch {
  localStorage.removeItem(progressKey);
}
let lastTrigger = null;
let celebrated =
  sessionStorage.getItem("kit-legal-ugc-celebrated-v2") === "yes";
let initialProgressRender = true;
function saveProgress() {
  try {
    localStorage.setItem(progressKey, JSON.stringify(progress));
  } catch {}
  renderProgress();
}
function showCelebration() {
  celebration.hidden = false;
  celebration.classList.add("is-visible");
  sessionStorage.setItem("kit-legal-ugc-celebrated-v2", "yes");
  celebrated = true;
}
function hideCelebration() {
  celebration.classList.remove("is-visible");
  celebration.hidden = true;
}
introNoteMotionControl?.addEventListener("click", () => {
  const paused = introNote.classList.toggle("is-paused");
  introNoteMotionControl.setAttribute("aria-pressed", String(paused));
  introNoteMotionControl.setAttribute(
    "aria-label",
    paused ? "Reanudar movimiento del mensaje" : "Pausar movimiento del mensaje"
  );
});
let downloadLabelTimeout;
downloadButton.addEventListener("click", () => {
  downloadButton.classList.add("is-expanded");
  window.clearTimeout(downloadLabelTimeout);
  downloadLabelTimeout = window.setTimeout(
    () => downloadButton.classList.remove("is-expanded"),
    2500
  );
});
function renderProgress() {
  const completed = stages.filter(
    (_, index) => progress[index]?.reviewed || progress[index]?.downloaded
  ).length;
  const downloaded = stages.reduce(
    (total, _, index) => total + (progress[index]?.downloadedCount || 0),
    0
  );
  const totalDocuments = stages.reduce(
    (total, stage) => total + stage.files.length,
    0
  );
  const reviewedDocuments = stages.reduce(
    (total, stage, index) =>
      total + Object.keys(progress[index]?.reviewedFiles || {}).length,
    0
  );
  const documentPercent = totalDocuments
    ? Math.round((reviewedDocuments / totalDocuments) * 100)
    : 0;
  progressCount.textContent = `${completed} de ${stages.length}`;
  progressBar.style.width = `${(completed / stages.length) * 100}%`;
  const pathwayProgress =
    Math.min(completed / Math.max(stages.length - 1, 1), 1) * 100;
  const nextBase = document.querySelector(
    `.base-${Math.min(completed + 1, stages.length)}`
  );
  pathway.style.setProperty(
    "--route-fill-color",
    getComputedStyle(nextBase).getPropertyValue("--base-pending").trim()
  );
  pathway.style.setProperty("--route-progress-opacity", completed ? "1" : "0");
  progressDetail.textContent =
    completed === stages.length
      ? `¡Ruta completa! Ya descargaste ${downloaded} documento${downloaded === 1 ? "" : "s"}.`
      : `Llevas ${completed} base${completed === 1 ? "" : "s"} revisada${completed === 1 ? "" : "s"} y ${downloaded} documento${downloaded === 1 ? "" : "s"} descargado${downloaded === 1 ? "" : "s"}.`;
  documentProgressLabel.textContent = `${documentPercent}% de archivos revisados`;
  documentProgressBar.style.width = `${documentPercent}%`;
  const nextIndex = stages.findIndex((_, index) => !progress[index]?.reviewed);
  if (nextIndex === -1) {
    nextStepTitle.textContent =
      "Ruta completa — vuelve a la base que necesites";
    nextStepButtonLabel.textContent = "Revisar Base 01";
    nextStepButton.dataset.stage = "0";
  } else {
    nextStepTitle.textContent = `${stages[nextIndex].step.replace("BASE ", "Base ")} — ${stages[nextIndex].title}`;
    nextStepButtonLabel.textContent = "Abrir esta base";
    nextStepButton.dataset.stage = String(nextIndex);
  }
  document.querySelectorAll(".base").forEach((button, index) => {
    const state = progress[index] || {};
    const done = Boolean(state.reviewed || state.downloaded);
    const wasDone = button.classList.contains("is-complete");
    button.classList.toggle("is-complete", done);
    if (!initialProgressRender && !wasDone && done)
      button.classList.add("is-newly-complete");
    else if (!done) button.classList.remove("is-newly-complete");
    button.setAttribute("aria-pressed", String(done));
    button.querySelector(".base-status").textContent = done ? "✓" : "";
  });
  const routeStart = pathway.getBoundingClientRect();
  const firstBadge = document
    .querySelector(".base-1 .base-number")
    .getBoundingClientRect();
  const lastBadge = document
    .querySelector(`.base-${stages.length} .base-number`)
    .getBoundingClientRect();
  const isMobile = window.matchMedia("(max-width: 800px)").matches;
  const axisStart = isMobile
    ? firstBadge.top + firstBadge.height / 2 - routeStart.top
    : firstBadge.left + firstBadge.width / 2 - routeStart.left;
  const axisEnd = isMobile
    ? lastBadge.top + lastBadge.height / 2 - routeStart.top
    : lastBadge.left + lastBadge.width / 2 - routeStart.left;
  const trackLength = axisEnd - axisStart;
  pathway.style.setProperty(
    "--route-progress-top",
    `${isMobile ? axisStart : firstBadge.top + firstBadge.height / 2 - routeStart.top}px`
  );
  pathway.style.setProperty(
    "--route-progress-left",
    `${isMobile ? firstBadge.left + firstBadge.width / 2 - routeStart.left : axisStart}px`
  );
  pathway.style.setProperty("--route-progress-track-size", `${trackLength}px`);
  pathway.style.setProperty(
    "--route-progress-size",
    `${(trackLength * pathwayProgress) / 100}px`
  );
  initialProgressRender = false;
  if (completed === stages.length && !celebrated) {
    showCelebration();
  }
}
function markReviewed(index) {
  progress[index] = { ...(progress[index] || {}), reviewed: true };
  saveProgress();
}
function markDownloaded(index, file) {
  const state = progress[index] || {};
  progress[index] = {
    ...state,
    downloaded: true,
    downloadedCount: (state.downloadedCount || 0) + 1,
    downloadedFiles: { ...(state.downloadedFiles || {}), [file]: true },
  };
  saveProgress();
}
function markPreviewed(index, file) {
  const state = progress[index] || {};
  progress[index] = {
    ...state,
    reviewedFiles: { ...(state.reviewedFiles || {}), [file]: true },
  };
  saveProgress();
}
function documentKind(file, index) {
  if (index === 0 && /script/i.test(file.label)) return "principal";
  return /contrato|anexo|carta|confirmaci[oó]n/i.test(file.label)
    ? "principal"
    : "apoyo";
}
function documentStatus(index, file) {
  const state = progress[index] || {};
  if (state.downloadedFiles?.[file.href])
    return ["Adaptación pendiente", "adaptacion"];
  if (state.reviewedFiles?.[file.href])
    return ["Vista previa consultada", "vista"];
  return ["Sin revisar", "sin-revisar"];
}
function updateDocumentStatus(index, file) {
  const row = document.querySelector(
    `.document-row[data-stage="${index}"][data-file="${CSS.escape(file.href)}"]`
  );
  if (!row) return;
  const badge = row.querySelector(".document-status");
  const [status, statusClass] = documentStatus(index, file);
  badge.className = `document-status ${statusClass}`;
  badge.textContent = status;
  badge.setAttribute("aria-label", `Estado: ${status}`);
}
function openStage(index, trigger) {
  const data = stages[index];
  if (!data) return;
  markReviewed(index);
  lastTrigger = trigger || document.activeElement;
  step.textContent = data.step;
  title.textContent = data.title;
  description.textContent = data.description;
  items.replaceChildren(
    ...data.items.map(item => {
      const li = document.createElement("li");
      li.textContent = item;
      return li;
    })
  );
  tip.textContent = data.tip;
  stagePaidAlert.hidden = index !== 3;
  stageFourWorkspace.hidden = index !== 3;
  downloadList.innerHTML = "";
  const groups = [
    ["principal", "Documento principal"],
    ["apoyo", "Material de apoyo"],
  ];
  groups.forEach(([kind, heading]) => {
    const files = data.files.filter(file => documentKind(file, index) === kind);
    if (!files.length) return;
    const group = document.createElement("li");
    group.className = "document-group";
    const headingElement = document.createElement("h3");
    headingElement.textContent = heading;
    group.appendChild(headingElement);
    const list = document.createElement("ul");
    list.className = "document-group-list";
    files.forEach(file => {
      const previewButton = document.createElement("button");
      previewButton.type = "button";
      previewButton.className = "button button-light preview-file";
      previewButton.textContent = "Ver vista previa";
      previewButton.setAttribute(
        "aria-label",
        `Ver vista previa: ${file.label}`
      );
      previewButton.addEventListener("click", () => openPreview(file, index));
      const actions = document.createElement("div");
      actions.className = "download-actions";
      actions.append(previewButton);
      const row = document.createElement("li");
      row.className = "document-row";
      row.dataset.stage = String(index);
      row.dataset.file = file.href;
      const label = document.createElement("span");
      label.className = "download-label";
      label.textContent = file.label;
      const [status, statusClass] = documentStatus(index, file);
      const statusBadge = document.createElement("span");
      statusBadge.className = `document-status ${statusClass}`;
      statusBadge.textContent = status;
      statusBadge.setAttribute("aria-label", `Estado: ${status}`);
      row.append(label, statusBadge, actions);
      list.appendChild(row);
    });
    group.appendChild(list);
    downloadList.appendChild(group);
  });
  if (typeof modal.showModal === "function") modal.showModal();
  else modal.setAttribute("open", "");
  document.querySelector(".modal-close").focus();
}
function closeStage() {
  if (modal.open && modal.close) modal.close();
  else modal.removeAttribute("open");
  if (lastTrigger) lastTrigger.focus();
}
let previewStageIndex = 0;
async function downloadPreviewFile(file, stageIndex) {
  if (previewDownload.disabled) return;
  previewDownload.disabled = true;
  previewDownload.setAttribute("aria-busy", "true");
  previewDownloadStatus.textContent = "";
  try {
    const filename = file.href.split("/").pop();
    const response = await fetch(
      `/api/kit-access/files/${encodeURIComponent(filename)}`,
      { credentials: "same-origin" }
    );
    if (!response.ok) {
      previewDownloadStatus.textContent =
        response.status === 401
          ? "Tu sesión puede haber caducado. Inicia sesión de nuevo para descargar."
          : response.status === 404
            ? "No encontramos este documento. Contacta con soporte."
            : `No se pudo descargar el documento (error ${response.status}). Inténtalo de nuevo.`;
      return;
    }
    const blob = await response.blob();
    if (
      !blob.size ||
      /^(text\/html|application\/json)\b/i.test(
        response.headers.get("content-type") || ""
      )
    ) {
      previewDownloadStatus.textContent =
        "El servidor no entregó un archivo válido. Inténtalo de nuevo o contacta con soporte.";
      return;
    }
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    markDownloaded(stageIndex, file.href);
    updateDocumentStatus(stageIndex, file);
    closePreview();
  } catch {
    previewDownloadStatus.textContent =
      "No se pudo conectar con el servidor para descargar. Comprueba tu conexión e inténtalo de nuevo.";
  } finally {
    previewDownload.disabled = false;
    previewDownload.removeAttribute("aria-busy");
  }
}
function openPreview(file, stageIndex) {
  previewStageIndex = stageIndex;
  markPreviewed(stageIndex, file.href);
  updateDocumentStatus(stageIndex, file);
  previewTitle.textContent = file.label;
  previewDescription.textContent =
    filePreviews[file.href] ||
    "Revisa el alcance, completa los campos entre corchetes y adapta el documento a tu colaboración.";
  previewPurpose.textContent =
    "Ordenar y documentar los acuerdos relacionados con este momento de la colaboración.";
  previewWhen.textContent =
    stages[stageIndex].title +
    ". Antes de compartirlo, producir o autorizar un uso adicional.";
  previewFields.textContent =
    "Completa los campos entre corchetes, fechas, precios, personas, plataformas y permisos que correspondan.";
  previewReview.textContent =
    "Si hay licencia amplia, exclusividad, menores, productos sensibles, publicidad pagada o una disputa.";
  previewDownloadStatus.textContent = "";
  previewDownload.onclick = () => downloadPreviewFile(file, stageIndex);
  if (typeof previewModal.showModal === "function") previewModal.showModal();
  else previewModal.setAttribute("open", "");
  previewModal.querySelector(".preview-close").focus();
}
function closePreview() {
  if (previewModal.open && previewModal.close) previewModal.close();
  else previewModal.removeAttribute("open");
}
function renderLegalProgress() {
  const values = legalValues();
  const groups = [
    ["ley", "jurisdiccion", "territorio", "plataformas"],
    ["cuenta", "inicio", "vencimiento"],
    ["paidMedia", "renovacion"],
  ];
  const complete = groups.filter(group =>
    group.every(name => String(values[name] || "").trim())
  ).length;
  legalFormProgress.textContent = `${complete} de 3 secciones completas`;
  legalFormProgressBar.style.width = `${(complete / 3) * 100}%`;
}
function validateLegalFields(showMissing = true) {
  const values = legalValues();
  const start = values.inicio;
  const end = values.vencimiento;
  const clearFieldError = input => {
    input.classList.remove("field-invalid");
    input.removeAttribute("aria-invalid");
    input.removeAttribute("aria-describedby");
  };
  const setFieldError = input => {
    input.classList.add("field-invalid");
    input.setAttribute("aria-invalid", "true");
    input.setAttribute("aria-describedby", legalFormAlert.id);
  };
  document
    .querySelectorAll("#legal-fields-form input")
    .forEach(clearFieldError);
  if (start && end && end < start) {
    setFieldError(legalForm.elements.inicio);
    setFieldError(legalForm.elements.vencimiento);
    legalFormAlert.hidden = false;
    legalFormAlert.textContent =
      "Revisa las fechas: el vencimiento no puede ser anterior al inicio.";
    return false;
  }
  if (showMissing && !end) {
    setFieldError(legalForm.elements.vencimiento);
    legalFormAlert.hidden = false;
    legalFormAlert.textContent =
      "Completa la fecha de vencimiento para dejar claro hasta cuándo aplican los permisos.";
    return false;
  }
  legalFormAlert.hidden = true;
  return true;
}
function downloadTextFile(filename, content, type = "text/plain") {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function exportChecklist() {
  const lines = [...document.querySelectorAll(".paid-media-checklist label")]
    .map(
      label =>
        `${label.querySelector("input").checked ? "[x]" : "[ ]"} ${label.textContent.trim()}`
    )
    .join("\n");
  downloadTextFile(
    "checklist-paid-media-ugc.txt",
    `Checklist de pauta UGC\n\n${lines}\n\nMaterial educativo y orientativo.`
  );
  copyFieldsStatus.textContent = "Checklist exportada con su estado actual.";
}
document
  .querySelectorAll("[data-stage]")
  .forEach(button =>
    button.addEventListener("click", () =>
      openStage(Number(button.dataset.stage), button)
    )
  );
document.querySelectorAll(".base").forEach(button =>
  button.addEventListener("animationend", event => {
    if (
      event.target === button.querySelector(".base-status") &&
      event.animationName === "base-check-stamp"
    )
      button.classList.remove("is-newly-complete");
  })
);
nextStepButton.addEventListener("click", () =>
  openStage(Number(nextStepButton.dataset.stage || 0), nextStepButton)
);
document.querySelector(".modal-close").addEventListener("click", closeStage);
globalProgressReset.addEventListener("click", () => {
  if (!confirm("¿Quieres reiniciar todo el progreso de etapas y documentos?"))
    return;
  progress = {};
  celebrated = false;
  sessionStorage.removeItem("kit-legal-ugc-celebrated-v2");
  hideCelebration();
  saveProgress();
});
celebrationClose.addEventListener("click", hideCelebration);
function copyWithFallback(text) {
  const textarea = document.createElement("textarea");
  textarea.value = text;
  textarea.setAttribute("readonly", "");
  textarea.style.position = "fixed";
  textarea.style.opacity = "0";
  document.body.appendChild(textarea);
  textarea.select();
  const copied = document.execCommand("copy");
  textarea.remove();
  if (!copied) throw new Error("copy-failed");
}
function legalValues() {
  return Object.fromEntries(new FormData(legalForm).entries());
}
function legalSummary() {
  const values = legalValues();
  return legalFieldLabels
    .map(([name, label]) => `${label}: ${values[name] || label}`)
    .join("\n");
}
function escapeHtml(value) {
  return String(value).replace(
    /[&<>"']/g,
    char =>
      ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;",
      })[char]
  );
}
function exportLegalWord() {
  const values = legalValues();
  const rows = legalFieldLabels
    .map(
      ([name, label]) =>
        `<tr><th>${escapeHtml(label)}</th><td>${escapeHtml(values[name] || "")}</td></tr>`
    )
    .join("");
  const html = `<!doctype html><html lang="es"><head><meta charset="utf-8"><title>Campos legales UGC</title><style>body{font-family:Arial,sans-serif;color:#252128;padding:40px}h1{font-size:24px}p{line-height:1.5}table{border-collapse:collapse;width:100%;margin-top:24px}th,td{border:1px solid #bbb;padding:10px;text-align:left}th{width:35%;background:#f7d3df;font-size:12px}td{font-size:12px}small{color:#666}</style></head><body><h1>Campos legales · Kit Legal UGC</h1><p>Resumen editable para revisar y adaptar a una colaboración concreta.</p><table>${rows}</table><p><small>Material educativo y orientativo. No sustituye asesoría jurídica personalizada.</small></p></body></html>`;
  const blob = new Blob([html], { type: "application/msword" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "campos-legales-ugc.doc";
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  copyFieldsStatus.textContent = "Archivo Word preparado.";
}
function exportLegalPdf() {
  const summary = escapeHtml(legalSummary()).replace(/\n/g, "<br>");
  const printWindow = window.open(
    "",
    "_blank",
    "noopener,noreferrer,width=820,height=900"
  );
  if (!printWindow) {
    copyFieldsStatus.textContent =
      "El navegador bloqueó la ventana de impresión. Permite ventanas emergentes para preparar el PDF.";
    return;
  }
  printWindow.document.write(
    `<!doctype html><html lang="es"><head><meta charset="utf-8"><title>Campos legales UGC</title><style>@page{margin:18mm}body{font-family:Arial,sans-serif;color:#252128;line-height:1.55}h1{font-size:24px;margin-bottom:8px}h2{font-size:14px;margin-top:28px;color:#df7398}.summary{border:1px solid #252128;border-radius:12px;padding:18px;font-size:12px}footer{margin-top:35px;font-size:10px;color:#666}</style></head><body><h1>Campos legales · Kit Legal UGC</h1><p>Resumen editable para revisar y adaptar a una colaboración concreta.</p><h2>Variables completadas</h2><div class="summary">${summary}</div><footer>Material educativo y orientativo. No sustituye asesoría jurídica personalizada.</footer><script>window.onload=()=>window.print()<\/script></body></html>`
  );
  printWindow.document.close();
  copyFieldsStatus.textContent =
    "Vista de impresión abierta: elige “Guardar como PDF”.";
}
function renderLegalFields() {
  let saved = {};
  try {
    saved = JSON.parse(localStorage.getItem(legalFieldsKey) || "{}");
  } catch {
    localStorage.removeItem(legalFieldsKey);
  }
  legalFieldLabels.forEach(([name]) => {
    if (saved[name] !== undefined) legalForm.elements[name].value = saved[name];
  });
  legalPreview.textContent = legalSummary();
}
legalForm.addEventListener("input", () => {
  legalPreview.textContent = legalSummary();
  renderLegalProgress();
  validateLegalFields(false);
});
legalForm.addEventListener("submit", event => {
  event.preventDefault();
  if (!validateLegalFields()) return;
  try {
    localStorage.setItem(legalFieldsKey, JSON.stringify(legalValues()));
    copyFieldsStatus.textContent = "Campos guardados en este navegador.";
  } catch {
    copyFieldsStatus.textContent =
      "No se pudieron guardar localmente; puedes copiar el resumen.";
  }
});
copyFieldsButton.addEventListener("click", async () => {
  const summary = legalSummary();
  try {
    copyWithFallback(summary);
    copyFieldsStatus.textContent =
      "Campos copiados. Pégalos en tu documento y completa cada variable.";
  } catch {
    try {
      await navigator.clipboard.writeText(summary);
      copyFieldsStatus.textContent =
        "Campos copiados. Pégalos en tu documento y completa cada variable.";
    } catch {
      copyFieldsStatus.textContent =
        "Selecciona y copia los campos manualmente desde la lista inferior.";
    }
  }
});
exportWordButton.addEventListener("click", exportLegalWord);
exportPdfButton.addEventListener("click", exportLegalPdf);
clearLegalButton.addEventListener("click", () => {
  if (!confirm("¿Quieres borrar los campos guardados en este navegador?"))
    return;
  legalForm.reset();
  localStorage.removeItem(legalFieldsKey);
  legalPreview.textContent = legalSummary();
  renderLegalProgress();
  legalFormAlert.hidden = true;
  copyFieldsStatus.textContent = "Formulario limpiado.";
});
exportChecklistButton.addEventListener("click", exportChecklist);
modal.addEventListener("click", event => {
  if (event.target === modal) closeStage();
});
modal.addEventListener("cancel", event => {
  event.preventDefault();
  closeStage();
});
previewModal
  .querySelector(".preview-close")
  .addEventListener("click", closePreview);
previewBack.addEventListener("click", closePreview);
previewModal.addEventListener("click", event => {
  if (event.target === previewModal) closePreview();
});
previewModal.addEventListener("cancel", event => {
  event.preventDefault();
  closePreview();
});
document.addEventListener("keydown", event => {
  if (event.key === "Escape" && modal.open) closeStage();
});
renderLegalFields();
renderLegalProgress();
window.addEventListener("resize", renderProgress);
renderProgress();

// Parallax suave del hero: cada capa se desplaza a distinta velocidad al bajar.
// Sin librerías, con rAF y respeto total a prefers-reduced-motion.
(() => {
  const layers = document.querySelectorAll("[data-parallax]");
  if (!layers.length || reduceMotion) return;
  const speeds = new Map();
  layers.forEach(layer => {
    const speed = Number.parseFloat(layer.dataset.parallax || "0");
    if (!Number.isFinite(speed) || speed === 0) return;
    speeds.set(layer, speed);
    layer.style.willChange = "transform";
  });
  if (!speeds.size) return;
  let ticking = false;
  const applyParallax = () => {
    ticking = false;
    const hero = document.querySelector(".hero");
    if (!hero) return;
    const heroBottom = hero.offsetTop + hero.offsetHeight;
    if (window.scrollY > heroBottom) return;
    speeds.forEach((speed, layer) => {
      layer.style.transform = `translate3d(0, ${(
        window.scrollY * speed
      ).toFixed(1)}px, 0)`;
    });
  };
  window.addEventListener(
    "scroll",
    () => {
      if (!ticking) {
        ticking = true;
        window.requestAnimationFrame(applyParallax);
      }
    },
    { passive: true }
  );
  applyParallax();
})();
