# Base 03 — Checklist de entrega y cobro

> **Antes de usar este documento:** duplica el archivo, completa todos los campos entre corchetes y elimina las instrucciones internas que no quieras enviar al cliente.

## Revisión técnica
- [ ] Formato correcto: [MP4 / MOV / JPG / OTRO]
- [ ] Resolución y orientación correctas.
- [ ] Audio, subtítulos y textos revisados.
- [ ] Archivos nombrados y organizados.
- [ ] Se eliminaron versiones internas y duplicados.

## Aprobación
- [ ] Se envió la entrega el [FECHA].
- [ ] La persona que aprueba es [NOMBRE].
- [ ] Se recibió feedback dentro del número de revisiones acordado.
- [ ] La aprobación final quedó por escrito.

## Cobro
- Importe pendiente: [IMPORTE]
- Fecha de vencimiento: [FECHA]
- Método de pago: [MÉTODO]
- Próximo seguimiento: [FECHA]

## Archivos finales
Enlace de entrega: [ENLACE]
Mensaje de cierre enviado: [SÍ / NO]
