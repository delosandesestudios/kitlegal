# Base 04 — Licencia para Paid Media, Meta Ads y Spark Ads

> **Antes de usar este documento:** duplica el archivo, completa todos los campos entre corchetes y elimina las instrucciones internas que no quieras enviar al cliente.

## Separar producción y publicidad
La creación del contenido y el permiso para convertirlo en anuncio son conceptos distintos. Confirma y cotiza cada uno por separado.

## Condiciones de la licencia
- Marca o anunciante: [NOMBRE]
- Piezas autorizadas: [LISTA]
- Plataformas: [META / TIKTOK / OTRAS]
- Tipo de uso: [ORGÁNICO / PAID MEDIA / WHITELISTING / SPARK ADS]
- Fecha de inicio: [FECHA]
- Fecha de finalización: [FECHA]
- Territorio: [PAÍS / REGIÓN / GLOBAL]
- Importe de la licencia: [IMPORTE]
- Renovación o extensión: [CONDICIÓN]
- Exclusividad: [SÍ / NO / CONDICIONES]

## Antes de autorizar
No entregues permisos indefinidos, globales o para cualquier canal sin comprender su alcance y sin reflejarlos en el precio y el acuerdo.
