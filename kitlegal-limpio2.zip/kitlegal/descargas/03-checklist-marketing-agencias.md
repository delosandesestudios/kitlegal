# Checklist operativo para marketing y agencias

## Fases de la colaboración

| Fase | Confirmar | Estado |
|---|---|---|
| 1. Brief y objetivos | Objetivo, público, mensaje, entregables, presupuesto y plataformas | [ ] |
| 2. Selección y confirmación | Creadora identificada, términos aprobados y persona responsable | [ ] |
| 3. Producto o información | Envío, instrucciones, logística y fecha de recepción | [ ] |
| 4. Producción y entrega | Guion, formatos, archivos originales y fecha de entrega | [ ] |
| 5. Revisión y aprobación | Número de cambios, registro de aprobaciones y versión final | [ ] |
| 6. Publicación, pauta y cierre | Publicación, campañas, medición, pago y archivo del proyecto | [ ] |

## Controles transversales

- [ ] Control de versiones y nombres de archivo.
- [ ] Registro de aprobaciones y persona autorizada.
- [ ] Control de archivos finales y originales.
- [ ] Confirmación de derechos de uso, imagen y voz.
- [ ] Verificación de Paid Media, cuenta publicitaria y plataformas.
- [ ] Control de vencimiento de licencias y procedimiento de apagado.
- [ ] Confirmación de pago y cierre documental.

> Adapta este checklist al flujo de la agencia y a la jurisdicción aplicable.
