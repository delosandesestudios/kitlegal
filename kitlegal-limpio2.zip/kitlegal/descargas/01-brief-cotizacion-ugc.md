# Base 01 — Brief, alcance y cotización UGC

> **Empieza aquí (2 min)**
> 1. Duplica este archivo.
> 2. Rellena solo lo marcado en amarillo: <mark>[ASÍ]</mark>
> 3. Borra este recuadro gris antes de enviarlo a la marca.

## Tus datos
- Creadora: <mark>[TU NOMBRE]</mark>

## Datos de la marca
- Cliente o marca: <mark>[NOMBRE]</mark>
- Persona de contacto: <mark>[NOMBRE Y CARGO]</mark>
- Producto o servicio: <mark>[DESCRIPCIÓN]</mark>
- Objetivo de la campaña: <mark>[OBJETIVO]</mark>
- Fecha de inicio y entrega: <mark>[FECHAS]</mark>

## Qué vas a entregar
- Piezas incluidas: <mark>[NÚMERO Y TIPO]</mark>
- Duración aproximada: <mark>[DURACIÓN]</mark>
- Formato y orientación: <mark>[FORMATO]</mark>
- Guion o concepto: <mark>[QUIÉN LO ENTREGA]</mark>
- Revisiones incluidas: <mark>[NÚMERO, ej. 2]</mark>
- Entrega de archivos raw: <mark>[SÍ / NO / PRECIO ADICIONAL]</mark>

## Cuánto cobras
- Producción (hacer el video): <mark>[IMPORTE]</mark>
- Revisiones extra (después de las incluidas): <mark>[IMPORTE O “no incluidas”]</mark>
- Urgencia: <mark>[IMPORTE]</mark>
- Uso orgánico (publicar sin pagar anuncios): <mark>[IMPORTE / DURACIÓN]</mark>
- Pauta / anuncios pagos (Meta Ads, Spark Ads, whitelisting): <mark>[IMPORTE / DURACIÓN / PAÍS]</mark>
- Forma y fecha de pago: <mark>[ej. 50% anticipo, saldo a 7 días]</mark>

## Confirmación
Para avanzar, la marca debe responder por escrito que acepta el alcance, el precio, las entregas, las revisiones, las fechas y los permisos de uso.
