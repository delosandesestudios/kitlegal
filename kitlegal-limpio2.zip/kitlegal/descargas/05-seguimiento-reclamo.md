# Base 05 — Seguimiento de pago y reclamo

> **Antes de usar este documento:** duplica el archivo, completa todos los campos entre corchetes y elimina las instrucciones internas que no quieras enviar al cliente.

## Registro
- Cliente: [NOMBRE]
- Proyecto: [NOMBRE]
- Importe pendiente: [IMPORTE]
- Fecha de vencimiento: [FECHA]
- Acuerdo o factura: [ENLACE / REFERENCIA]
- Persona responsable del pago: [NOMBRE / EMAIL]

## Primer seguimiento
Hola, [NOMBRE]. Te escribo para dar seguimiento al pago de [PROYECTO], por importe de [IMPORTE], cuyo vencimiento estaba previsto para [FECHA]. ¿Podrías confirmarme la fecha estimada de pago? Gracias.

## Segundo seguimiento
Hola, [NOMBRE]. Retomo este mensaje porque el pago de [PROYECTO] continúa pendiente. Según nuestro acuerdo, el vencimiento era [FECHA]. Agradezco que me confirmes una fecha concreta de regularización antes del [FECHA].

## Documentación que conviene guardar
- [ ] Propuesta y cotización.
- [ ] Contrato o confirmación escrita.
- [ ] Entregas y aprobaciones.
- [ ] Factura y comprobantes.
- [ ] Mensajes y fechas de seguimiento.
