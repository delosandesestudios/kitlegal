# Checklist final para clientes

## 1) Antes de aceptar
- Confirmar brief, entregables, fechas, presupuesto y aprobación final.
- Revisar usos previstos de la marca, redes, contenido y campañas publicitarias.
- Confirmar si existe exclusividad, revisión de edición, derechos de archivo o reposteo.
- Pedir respuesta por escrito antes de grabar o entregar el material.

## 2) Antes de grabar
- Dejar documentado el alcance, el precio, el anticipo y la fecha de entrega.
- Confirmar el número de revisiones, volumen de entregables y formatos finales.
- Revisar permisos, derechos de imagen, voz y uso comercial.
- Guardar el mensaje, email o comprobante de aceptación.

## 3) Antes de entregar
- Comprobar que el archivo final coincide con lo aprobado.
- Revisar que el formato, resolución, texto y versiones estén listos.
- Confirmar el plazo de pago y la vía de facturación.
- Enviar el producto final con instrucciones de uso y cierre documental.

## 4) Si hay anuncios o Paid Media
- Definir claramente las plataformas, la duración, el territorio y el alcance del permiso.
- Especificar si la marca puede usar el contenido como whitelisting, Spark Ads, Meta Ads o campañas.
- Establecer tarifa por uso publicitario y posibilidad de renovación.
- Guardar la autorización por escrito con fecha y firma, si aplica.

## 5) Si aparece un problema
- Enviar seguimientos por escrito y exigir una fecha concreta.
- Guardar evidencia del trabajo realizado, conversaciones y entregables rechazados.
- Solicitar el pago pendiente o la subsanación del incumplimiento en un plazo claro.
- Usar la carta de cobro o de reclamo como documento formal.

## 6) Recomendación final
- Mantén todo en un archivo único por colaboración.
- No te quedes con acuerdos verbales; conviértelos en un texto claro.
- Si una marca quiere algo que no está en el brief, cuesta extra o licencia adicional, debe quedar documentado.

> Material orientativo para ayudar a ordenar la colaboración. No sustituye asesoría jurídica personalizada.
