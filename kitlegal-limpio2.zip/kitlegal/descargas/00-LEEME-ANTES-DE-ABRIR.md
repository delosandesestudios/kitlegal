# Kit Legal UGC — empieza aquí

## Tu primera decisión

En **Base 02 — Antes de grabar**, elige **una sola opción** para dejar constancia del acuerdo:

1. **Confirmación antes de grabar — control interno de la creadora**
   - Usa `02-confirmacion-antes-de-grabar.md`.
   - Te ayuda a comprobar que producto, objetivo, entregables, precio, fechas, revisiones y permisos están claros antes de encender la cámara.
   - No es el mensaje express para enviar a la marca.

2. **Versión Word formal**
   - Usa `02-confirmacion-de-acuerdos.docx`.
   - Es la versión Word editable de la misma confirmación.
   - Completa los campos amarillos, revisa el documento y envíalo a la marca cuando quieras dejar el acuerdo ordenado en formato formal.

3. **Confirmación express por WhatsApp, correo o DM**
   - Usa `02-confirmacion-acuerdos-completa.md`.
   - Copia el mensaje, completa los campos y pide que respondan: **“Acepto estos términos”**.
   - No la uses como un documento adicional si ya enviaste la versión Word: elige una sola vía de confirmación.

## Ruta recomendada

1. **Base 01 — Antes de aceptar:** responde, pregunta y negocia.
2. **Base 02 — Antes de grabar:** confirma alcance, precio, pagos, revisiones y permisos.
3. **Base 03 — Antes de entregar:** revisa calidad, archivos y cobro.
4. **Base 04 — Antes de autorizar anuncios:** delimita Paid Media, Meta Ads, Whitelisting y Spark Ads.
5. **Base 05 — Si ocurre un problema:** deja constancia de pagos pendientes, incumplimientos y soluciones.

## Cómo identificar los campos

- **Amarillo:** campos que debe completar la creadora.
- **Rosa:** instrucciones o contexto.
- **Coral:** advertencias y límites.
- **Verde suave:** confirmaciones, aprobación y cierre.
- **Gris:** contenido interno que debe borrarse antes de enviar.

## Antes de enviar cualquier documento

- Comprueba que el producto o servicio y el objetivo estén descritos.
- Revisa cantidad de piezas, formato, duración y fechas.
- Confirma precio, moneda, anticipo, saldo y método de pago.
- Verifica el número de revisiones y qué se considera trabajo adicional.
- Separa uso orgánico, Paid Media, Whitelisting/Spark Ads, territorio y duración.
- Revisa por separado imagen, voz, nombre de usuario y cuenta publicitaria.
- Borra los recuadros grises de uso interno.
- Guarda una copia del documento enviado y de la aceptación escrita.

> Las plantillas ayudan a ordenar la colaboración; no sustituyen la revisión profesional de un caso complejo, una licencia amplia, exclusividad, productos sensibles o una disputa.
