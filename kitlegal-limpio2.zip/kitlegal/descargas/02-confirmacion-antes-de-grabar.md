# Base 02 — Confirmación antes de grabar

> **USO INTERNO — CONTROL DE LA CREADORA**
> Esta plantilla sirve para dejar todo listo antes de grabar. No es el mensaje express para enviar: para obtener un “Acepto estos términos”, usa la confirmación express por WhatsApp, correo o DM.

> **Empieza aquí (2 min)**
> 1. Duplica este archivo.
> 2. Rellena solo lo marcado en amarillo.
> 3. Revisa producto, objetivo, entregables, precio, fechas, revisiones y permisos.
> 4. No enciendas la cámara hasta tener la aprobación escrita y el anticipo, si lo acordaron.

## Datos de la marca y aprobación
- Cliente que contrata: <mark>[NOMBRE LEGAL O COMERCIAL]</mark>
- Persona autorizada para aprobar: <mark>[NOMBRE, CARGO Y EMAIL]</mark>

## Producto, objetivo y alcance
- Producto o servicio: <mark>[PRODUCTO / SERVICIO]</mark>
- Objetivo o concepto del contenido: <mark>[OBJETIVO / CONCEPTO]</mark>
- Entregables finales: <mark>[CANTIDAD DE VIDEOS / PIEZAS]</mark>
- Formato y duración: <mark>[FORMATO / DURACIÓN]</mark>
- Fecha de grabación: <mark>[FECHA]</mark>
- Fecha de primera entrega: <mark>[FECHA]</mark>
- Fecha límite para comentarios consolidados: <mark>[FECHA / NÚMERO DE DÍAS HÁBILES]</mark>

## Precio, revisiones y pagos
- Precio total: <mark>[MONTO TOTAL]</mark>
- Moneda: <mark>[USD / VES / OTRA]</mark>
- Anticipo: <mark>[PORCENTAJE / IMPORTE / FECHA]</mark>
- Saldo y fecha o condición de pago: <mark>[CONDICIÓN]</mark>
- Número de revisiones y límite: <mark>[NÚMERO / QUÉ INCLUYE]</mark>

## Permisos que deben estar claros antes de grabar
- Uso del video en canales orgánicos: <mark>[SÍ / NO / CANALES]</mark>
- Uso de imagen: <mark>[ALCANCE]</mark>
- Uso de voz: <mark>[ALCANCE]</mark>
- Paid Media: <mark>[SÍ / NO / PLATAFORMAS / TERRITORIO / DURACIÓN / CANON / RENOVACIÓN]</mark>
- Cuenta publicitaria: <mark>[ID / NOMBRE]</mark>
- Whitelisting o Spark Ads: <mark>[SÍ / NO / CONDICIONES]</mark>
- Territorio: <mark>[PAÍS / REGIÓN / GLOBAL]</mark>
- Duración de los permisos: <mark>[PLAZO]</mark>
- Exclusividad: <mark>[SÍ / NO / CONDICIONES]</mark>

## Antes de encender la cámara
Confirma que el brief está aprobado, que las condiciones comerciales están claras y que los permisos de uso están delimitados. Si algo cambió, actualiza esta hoja antes de grabar.
