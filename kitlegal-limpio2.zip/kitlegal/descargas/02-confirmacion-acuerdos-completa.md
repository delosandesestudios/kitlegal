# Confirmación express por WhatsApp, correo o DM

> **Elige una sola opción:** documento Word formal o mensaje express.
> Esta plantilla sirve para obtener una respuesta escrita de aceptación. Copia el mensaje, completa los campos y pide que respondan: **“Acepto estos términos”**.

Hola, <mark>[NOMBRE DE MARCA / AGENCIA]</mark>. Para confirmar nuestro acuerdo de contenido UGC:

**Partes y aprobación**
- Marca o agencia: <mark>[NOMBRE]</mark>
- Creadora: <mark>[TU NOMBRE]</mark>
- Persona autorizada para aprobar: <mark>[NOMBRE Y CARGO]</mark>

**Producto y contenido**
- Producto o servicio: <mark>[PRODUCTO / SERVICIO]</mark>
- Objetivo o concepto: <mark>[OBJETIVO / CONCEPTO]</mark>
- Cantidad de videos o piezas: <mark>[CANTIDAD]</mark>
- Formato y duración: <mark>[FORMATO / DURACIÓN]</mark>

**Precio, pagos y revisiones**
- Precio total y moneda: <mark>[MONTO / MONEDA]</mark>
- Anticipo y fecha o condición: <mark>[MONTO / FECHA]</mark>
- Saldo y fecha o condición: <mark>[MONTO / FECHA]</mark>
- Revisiones incluidas: <mark>[NÚMERO / LÍMITE]</mark>
- Fecha de entrega: <mark>[FECHA]</mark>

**Permisos de uso**
- Uso orgánico: <mark>[SÍ / NO / CANALES]</mark>
- Paid Media: <mark>[SÍ / NO / PLATAFORMAS / TERRITORIO / DURACIÓN / CANON / RENOVACIÓN]</mark>
- Whitelisting o Spark Ads: <mark>[SÍ / NO / CONDICIONES]</mark>
- Cuenta publicitaria: <mark>[ID / NOMBRE]</mark>
- Territorio: <mark>[PAÍS / REGIÓN / GLOBAL]</mark>
- Duración del permiso: <mark>[PLAZO]</mark>
- Uso de imagen: <mark>[ALCANCE]</mark>
- Uso de voz: <mark>[ALCANCE]</mark>

Por favor, responde **“Acepto estos términos”** o indica cualquier cambio antes de iniciar la producción.

---

## Registro de aceptación — no lo envíes
- Fecha: <mark>[FECHA]</mark>
- Persona que aceptó: <mark>[NOMBRE]</mark>
- Canal: <mark>[WhatsApp / email / DM]</mark>
- Mensaje o captura archivada en: <mark>[CARPETA O ENLACE]</mark>

> Un “acepto” por mensaje deja constancia, pero no reemplaza un contrato si te piden derechos muy amplios, exclusividad, anuncios pagos o hay un conflicto.
