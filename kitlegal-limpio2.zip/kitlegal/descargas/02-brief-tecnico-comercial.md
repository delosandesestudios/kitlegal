# Plantilla de brief técnico y comercial UGC

> Completa este brief antes de confirmar la producción. Adáptalo a la colaboración concreta.

## Objetivo de campaña
- Objetivo:
- Indicador principal:

## Público objetivo
- Audiencia:
- Mercado / territorio:

## Mensaje principal
- Mensaje:
- Claims que deben evitarse o comprobarse:

## Tono y referencias
- Tono:
- Referencias aprobadas:

## Guion o puntos obligatorios
- Hook:
- Puntos obligatorios:
- Llamado a la acción:

## Entregables
- Cantidad:
- Duración:
- Archivos originales incluidos: [SÍ / NO]

## Formatos y especificaciones técnicas
- Formato:
- Resolución / relación de aspecto:
- Subtítulos / audio / textos:

## Calendario
- Envío de primera versión:
- Fecha de aprobación:
- Fecha de publicación:

## Producto, envío y logística
- Producto:
- Dirección y responsable de envío:
- Devolución o disposición del producto:

## Aprobación y presupuesto
- Persona responsable de aprobar:
- Presupuesto:
- Moneda:
- Forma y fecha de pago:

## Plataformas y uso
- Plataformas:
- Territorio:
- Uso orgánico:
- Paid Media / duración / tarifa:

> Nota: un brief claro no reemplaza la confirmación escrita de los acuerdos ni la revisión profesional cuando el caso sea complejo.
