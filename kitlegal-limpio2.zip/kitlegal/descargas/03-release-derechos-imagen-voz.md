# Release de derechos de imagen, voz e identidad

> Documento de trabajo. Debe ser revisado y adaptado al caso, país y alcance de la autorización.

## Partes
- Persona autorizante:
- Marca o agencia:
- Creadora / titular del contenido:

## Contenido y autorización
- Descripción del contenido:
- Uso de imagen:
- Uso de voz:
- Uso de nombre o identidad:
- Finalidad comercial:

## Alcance de uso
- Plataformas autorizadas:
- Cuenta publicitaria autorizada:
- Territorio:
- Duración:
- Paid Media y Ads:
- Whitelisting / Partnership Ads / Spark Ads: [SÍ / NO]

## Ediciones permitidas
- Recortes:
- Subtítulos:
- Doblajes:
- Variaciones o nuevas ediciones:
- Aprobación previa requerida: [SÍ / NO]

## Compensación y límites
- Compensación:
- Renovación o ampliación de territorio, plataformas o vigencia:
- Limitaciones y condiciones:
- Procedimiento de apagado y eliminación de accesos:

## Aceptación
- Firma o aceptación:
- Fecha:
- Persona autorizada:

> Las licencias amplias, perpetuas o internacionales, el uso de menores, productos sensibles o disputas de titularidad requieren revisión profesional.
