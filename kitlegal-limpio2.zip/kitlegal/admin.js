const loginView = document.querySelector("#login-view");
const adminView = document.querySelector("#admin-view");
const loginNotice = document.querySelector("#login-notice");
const buyerNotice = document.querySelector("#buyer-notice");
const buyersList = document.querySelector("#buyers-list");

function showNotice(target, message, type = "") {
  target.textContent = message;
  target.className = `notice ${type}`.trim();
}

async function requestJson(url, options = {}) {
  const response = await fetch(url, {
    credentials: "same-origin",
    ...options,
    headers: { ...(options.headers || {}), Accept: "application/json" },
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || "La solicitud no se pudo completar.");
  return data;
}

async function loadBuyers() {
  const buyers = await requestJson("/api/kit-access/admin/buyers");
  buyersList.replaceChildren();
  if (!buyers.length) {
    const empty = document.createElement("p");
    empty.className = "hint";
    empty.textContent = "Todavía no hay compradoras registradas.";
    buyersList.append(empty);
    return;
  }

  for (const buyer of buyers) {
    const row = document.createElement("article");
    row.className = "buyer";
    const information = document.createElement("div");
    const email = document.createElement("strong");
    email.className = "buyer-email";
    email.textContent = buyer.email;
    const status = document.createElement("span");
    status.className = "buyer-status";
    status.textContent = buyer.active ? "Acceso activo" : "Acceso revocado";
    information.append(email, status);

    const actions = document.createElement("div");
    actions.className = "actions";
    const toggle = document.createElement("button");
    toggle.className = "ghost";
    toggle.type = "button";
    toggle.textContent = buyer.active ? "Revocar" : "Reactivar";
    toggle.addEventListener("click", () => updateBuyer(buyer.email, { active: !buyer.active }));
    const reset = document.createElement("button");
    reset.className = "ghost";
    reset.type = "button";
    reset.textContent = "Asignar clave nueva";
    reset.addEventListener("click", () => resetBuyerCode(buyer.email));
    actions.append(toggle, reset);
    row.append(information, actions);
    buyersList.append(row);
  }
}

function showAdmin() {
  loginView.hidden = true;
  adminView.hidden = false;
  loadBuyers().catch(error => showNotice(buyerNotice, error.message, "error"));
}

function showLogin() {
  adminView.hidden = true;
  loginView.hidden = false;
}

document.querySelector("#admin-login-form").addEventListener("submit", async event => {
  event.preventDefault();
  const email = document.querySelector("#admin-email").value.trim();
  const password = document.querySelector("#admin-password").value;
  try {
    await requestJson("/api/kit-access/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    document.querySelector("#admin-password").value = "";
    showNotice(loginNotice, "");
    showAdmin();
  } catch (error) {
    showNotice(loginNotice, error.message, "error");
  }
});

document.querySelector("#buyer-form").addEventListener("submit", async event => {
  event.preventDefault();
  const email = document.querySelector("#buyer-email").value.trim();
  const code = document.querySelector("#buyer-code").value;
  try {
    await requestJson("/api/kit-access/admin/buyers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, code }),
    });
    document.querySelector("#buyer-form").reset();
    showNotice(buyerNotice, `Acceso creado para ${email}. Guarda la clave para compartirla: ${code}`, "success");
    await loadBuyers();
  } catch (error) {
    showNotice(buyerNotice, error.message, "error");
  }
});

async function updateBuyer(email, changes) {
  try {
    await requestJson(`/api/kit-access/admin/buyers/${encodeURIComponent(email)}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(changes),
    });
    showNotice(buyerNotice, changes.active ? "Acceso reactivado." : "Acceso revocado.", "success");
    await loadBuyers();
    return true;
  } catch (error) {
    showNotice(buyerNotice, error.message, "error");
    return false;
  }
}

async function resetBuyerCode(email) {
  const code = window.prompt(`Escribe la nueva clave para ${email} (mínimo 6 caracteres):`);
  if (code === null) return;
  if (code.length < 6) {
    showNotice(buyerNotice, "La clave nueva debe tener al menos 6 caracteres.", "error");
    return;
  }
  const updated = await updateBuyer(email, { code });
  if (updated) {
    showNotice(buyerNotice, `Clave actualizada para ${email}. Guárdala y comunícala de forma segura: ${code}`, "success");
  }
}

document.querySelector("#logout-btn").addEventListener("click", async () => {
  try {
    await requestJson("/api/kit-access/admin/logout", { method: "POST" });
    showLogin();
  } catch (error) {
    showNotice(buyerNotice, error.message, "error");
  }
});

requestJson("/api/kit-access/admin/session")
  .then(data => data.ok ? showAdmin() : showLogin())
  .catch(error => {
    showLogin();
    showNotice(loginNotice, error.message, "error");
  });
