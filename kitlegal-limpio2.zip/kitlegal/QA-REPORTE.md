# Reporte QA — Kit Legal para Creadoras UGC

## Correcciones aplicadas

- Corregido el enlace de navegación **Qué incluye**, que apuntaba a `#incluye`; ahora apunta a la sección real `#includes`.
- Corregida la ruta del favicon para que responda desde `public/favicon.svg`.
- Eliminado `role="listitem"` de los botones de etapa para conservar correctamente su semántica y navegación con teclado como botones.
- Añadido manejo seguro para un `localStorage` corrupto: el progreso se reinicia sin romper la página.
- Añadido cierre accesible del modal mediante el evento nativo `cancel` de `<dialog>` y restauración del foco al botón que lo abrió.
- Añadida la sección **Marco venezolano e internacional**, que separa ley aplicable, controversias, imagen, derechos, personas, datos, publicidad y plataformas.
- Añadido el botón **Copiar campos editables**, con soporte para Clipboard API y fallback compatible con navegadores que bloquean ese permiso.
- Convertidos los campos legales en un formulario editable con vista previa, guardado local y resumen copiable.
- Añadida checklist de pauta para cuentas autorizadas, whitelisting, Partnership Ads, Spark Ads, control de cuentas, apagado, accesos, ediciones y renovaciones.
- Añadida la sección **Cuando una plantilla ya no basta**, con 7 tarjetas independientes para orientar cuándo pedir asesoría 1:1.
- Eliminada la frase hero solicitada y reemplazada por un encabezado descriptivo más directo.
- Cambiado el flujo de documentos: la etapa ya no descarga directamente; primero muestra una vista previa y desde esa vista se habilita la descarga.
- Añadido el bloque editorial **Momento de estudiar** entre la introducción y la ruta, con texto educativo, desplazamiento interno y representación visual de un contrato UGC transfronterizo.
- Añadido el aviso importante sobre el carácter educativo y orientativo del material.
- Añadidas acciones **Exportar Word** y **Preparar PDF** para el formulario legal. Word genera un archivo `.doc` local; PDF abre una vista de impresión para elegir “Guardar como PDF”.
- Añadidas cuatro plantillas: brief técnico-comercial, confirmación de acuerdos por mensaje, checklist operativo para marketing/agencias y release de imagen, voz e identidad.
- El formulario legal ahora está dividido en tres grupos plegables: ley y alcance; pauta y vigencia; tarifas. Esto reduce la carga cognitiva en teléfonos y mantiene el resumen completo.
- Añadido indicador `0 de 3 secciones completas`, validación visual de campos, aviso de vencimiento faltante o inválido, botón de limpieza con confirmación y exportación de checklist marcada.
- Enriquecida la vista previa de cada documento con propósito, momento de uso, campos a completar, casos que requieren revisión profesional, descarga y regreso a la etapa.
- Explicado literalmente dentro del formulario que el contexto legal son los datos que determinan qué reglas y permisos aplican: ley, jurisdicción, territorio, plataformas y vigencia.
- Restaurada la hoja de estilos completa después de detectar que una escritura incremental la había sobrescrito; la página vuelve a cargar con el diseño visual original y las capas nuevas.
- Añadida puerta de acceso de prototipo con código configurable, sesión temporal y aviso explícito de que no reemplaza validación de servidor.
- Añadido mapa visible de las cinco bases y los documentos principales de cada una.
- Añadido progreso global en el header para mostrar el porcentaje de documentos revisados mediante vista previa.
- Añadido botón de reinicio global y descarga del paquete `kit-legal-ugc-documentos-word.zip`.
- Añadida la nota de uso editable al inicio de los 11 archivos Word actuales.
- Añadida tarjeta dinámica **Siguiente paso recomendado**, que lleva a la primera base aún no revisada y cambia a “Ruta completa” al terminar.
- Separados los documentos de cada etapa en **Documento principal** y **Material de apoyo**; cada archivo muestra `Sin revisar`, `Vista previa consultada` o `Adaptación pendiente`.
- Añadida advertencia específica en Base 04: Paid Media, Whitelisting y Spark Ads no están incluidos automáticamente en la creación del contenido.
- Añadido WhatsApp como acción secundaria en la sección de asesoría, manteniendo la ruta principal y la compra como acciones prioritarias.
- Reforzada accesibilidad: foco visible, controles con área táctil mínima, estados con texto además de color, etiquetas de vista previa y capa de acceso completa en móvil.
- Auditoría WCAG: se corrigió el rosa de acciones con texto blanco a `#a9446c`, con contraste calculado 5.63:1; se reforzó el foco visible con tinta oscura y se verificó que los 23 botones tienen `type` explícito.
- Prueba móvil específica a 320 px: acceso centrado, sin desbordamiento horizontal y controles táctiles visibles.
- Prueba de interacción con CDP: `Sin revisar` → `Vista previa consultada` al abrir la vista previa → `Adaptación pendiente` al descargar; el siguiente paso avanzó a Base 02.
- Ajustado el header para 320 px: el progreso se trunca de forma accesible y el botón ZIP permanece visible; `scrollWidth` quedó en 320 px, igual al viewport, sin overflow horizontal.
- Rediseñado el módulo de entrada como bienvenida editorial especial: ahora solicita correo de compra y código especial, incorpora detalles decorativos suaves y mantiene la paleta/tipografías existentes.
- Reparada la animación de **Entrar a la ruta**: la flecha tiene un movimiento sutil independiente, sin desplazar ni deformar el botón.
- Integrado el botón animado enviado para el acceso: estado inicial **Entrar al kit**, estado confirmado **Dentro del kit**, borde luminoso, despegue del avión, estela y check de confirmación.
- El botón solo cambia al estado confirmado después de validar correctamente correo y código; se desactiva durante la animación y después abre el kit.
- Aclaración de seguridad: el correo y código se validan localmente en este prototipo; para una versión comercial, el código debe validarse en servidor o en la plataforma de entrega.
- Añadido sonido sutil de hover y confirmación mediante Web Audio API, activado solo después de una interacción del usuario y sin archivo de audio externo.
- La animación del avión ahora depende de la clase `.is-sending`, no de `:focus`, y funciona con clic, teclado y touch; se añadió `aria-busy` y soporte para `prefers-reduced-motion`.
- Botón responsive verificado en 320, 390 y 768 px: conserva el aspecto neumórfico, no genera desplazamiento horizontal y mantiene un área táctil usable.
- Cambiado el texto visible del botón a **Acceder ahora**; el estado confirmado conserva **Dentro del kit**.
- Auditoría móvil posterior: sin excepciones JavaScript ni entradas de consola persistentes; el único evento inicial fue una notificación del entorno de prueba, no un error de la aplicación.
- Responsive verificado en 320, 390, 412 y 768 px: ancho del botón 200 px, `scrollWidth` sin desbordamiento en teléfonos y transición válida `default → is-sending → gate cerrado`.

## Optimización adicional aplicada

- No se incorporaron librerías nuevas ni frameworks: se mantiene JavaScript y CSS nativos para evitar peso de dependencias.
- La nueva funcionalidad reutiliza el DOM existente y usa una sola cadena de variables, sin peticiones de red adicionales.
- El flujo de copiado elimina inmediatamente el textarea temporal usado por el fallback.
- La sección legal usa CSS responsive y no añade imágenes ni fuentes nuevas.
- El modal construye sus listas con `textContent` y nodos DOM, evitando interpolación HTML innecesaria.
- Se añadió `meta referrer="strict-origin-when-cross-origin"` para limitar la exposición de URLs al salir del sitio.
- El guardado del progreso tolera fallos de almacenamiento privado sin detener la interfaz.

## Pruebas realizadas

| Área | Resultado |
|---|---|
| Sintaxis JavaScript (`node --check`) | PASS |
| Anclas internas | PASS — todas apuntan a IDs existentes |
| Favicon | PASS — HTTP 200 |
| Manifiesto `/manus-routes.json` | PASS — HTTP 200 y JSON válido |
| Etapas de la ruta | PASS — las 5 abren su modal |
| Documentos descargables | PASS — 11 enlaces construidos y archivos existentes |
| Cierre del modal con Escape | PASS |
| Reinicio de progreso | PASS |
| FAQ desplegable | PASS — 8 preguntas detectadas y apertura/cierre funcional |
| Overflow horizontal | PASS — no se detectó desbordamiento en la vista probada |
| Formulario legal editable | PASS — guarda, restaura y actualiza la vista previa |
| Checklist de pauta | PASS — 7 controles interactivos |
| Modal tras nueva sección | PASS — Base 04 abre 2 documentos |
| Vista previa antes de descarga | PASS — 2 previews, 0 enlaces de descarga directa en Base 04 |
| Tarjetas de asesoría 1:1 | PASS — 7 supuestos independientes |
| Momento de estudiar | PASS — bloque visible entre introducción y ruta, responsive |
| Exportación de formulario | PASS — Word local y flujo de impresión PDF |
| Nuevas plantillas | PASS — Base 02 muestra 5 documentos y Base 03 muestra 4 |
| Formulario móvil por grupos | PASS — 3 grupos plegables y controles táctiles |
| Validación de fechas | PASS — marca ambos campos y muestra alerta cuando el vencimiento es anterior |
| Vista previa enriquecida | PASS — 4 bloques informativos y botón de regreso |
| Hoja de estilos | PASS — 35 KB servidos, diseño visible local y públicamente |
| Puerta de acceso | PASS — código válido oculta el gate y conserva la sesión |
| Mapa de documentos | PASS — 5 bases visibles con sus documentos principales |
| ZIP Word | PASS — 11 DOCX, ZIP íntegro y servido desde `descargas/` |
| Progreso global | PASS — cuenta documentos al abrir su vista previa |
| Siguiente paso | PASS — recomienda la primera base pendiente y cambia al completar la ruta |
| Categorías y estados | PASS — principales/apoyo y tres estados textuales por documento |
| Accesibilidad responsive | PASS — capturas en 320, 375, 390, 412, 768 y 1440 px |
| Contraste y botones WCAG | PASS — acción rosa 5.63:1, 23/23 botones con type, foco visible |
| Estados por clic | PASS — transición verificada con navegador automatizado |
| Responsive 320 px | PASS — captura generada sin corte visible |
| Responsive 375 px | PASS — captura generada sin corte visible |
| Tablet 768 px | PASS — captura generada sin corte visible |
| Escritorio 1440 px | PASS — captura generada sin corte visible |

## Archivos principales modificados

- `index.html`
- `script.js`

Las capturas de control quedaron en `qa-screens/` dentro del proyecto.
