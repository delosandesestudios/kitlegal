CREATE TABLE IF NOT EXISTS `kit_buyers` (
  `id` int AUTO_INCREMENT NOT NULL,
  `email` varchar(320) NOT NULL,
  `codeHash` varchar(255) NOT NULL,
  `accessVersion` int NOT NULL DEFAULT 1,
  `active` boolean NOT NULL DEFAULT 1,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `kit_buyers_id` PRIMARY KEY(`id`),
  CONSTRAINT `kit_buyers_email_unique` UNIQUE(`email`)
);
