import { describe, expect, it } from "vitest";
import {
  createAccessToken,
  createSessionToken,
  hashAccessCode,
  KIT_ACCESS_COOKIE,
  KIT_ADMIN_COOKIE,
  normalizeEmail,
  readCookieValue,
  verifyAccessCode,
  verifyAccessToken,
  verifySessionToken,
} from "./_core/access";

describe("kit access security helpers", () => {
  it("stores buyer codes as salted scrypt hashes and verifies them", () => {
    const storedHash = hashAccessCode("a-unique-buyer-secret");

    expect(storedHash).toMatch(/^scrypt:/);
    expect(storedHash).not.toContain("a-unique-buyer-secret");
    expect(verifyAccessCode("a-unique-buyer-secret", storedHash)).toBe(true);
    expect(verifyAccessCode("wrong-secret", storedHash)).toBe(false);
    expect(verifyAccessCode("a-unique-buyer-secret", "invalid-hash")).toBe(false);
  });

  it("signs expiring buyer sessions and rejects tampering and cross-purpose use", () => {
    const token = createAccessToken("buyer@example.com", "unit-test-secret");

    expect(verifyAccessToken(token, "unit-test-secret")).toBe("buyer@example.com");
    expect(verifyAccessToken(token, "wrong-secret")).toBeNull();
    expect(verifySessionToken(token, "admin", "unit-test-secret")).toBeNull();
    expect(verifyAccessToken(`${token}tampered`, "unit-test-secret")).toBeNull();
  });

  it("uses separate buyer/admin cookie names and safely reads cookies", () => {
    expect(KIT_ACCESS_COOKIE).not.toBe(KIT_ADMIN_COOKIE);
    expect(readCookieValue("other=1; kit_ugc_access=abc%2E123", KIT_ACCESS_COOKIE)).toBe("abc.123");
    expect(readCookieValue("kit_ugc_access=%E0%A4%A", KIT_ACCESS_COOKIE)).toBeUndefined();
  });

  it("normalizes emails to enforce a single canonical buyer identity", () => {
    expect(normalizeEmail(" Buyer+Tag@Example.com ")).toBe("buyer+tag@example.com");
    expect(normalizeEmail("invalid-email")).toBeUndefined();
    expect(normalizeEmail("   ")).toBeUndefined();
  });

  it("expires session tokens after their configured lifetime", () => {
    const token = createSessionToken("admin@example.com", "admin", "unit-test-secret");

    expect(verifySessionToken(token, "admin", "unit-test-secret")).toBe("admin@example.com");
    expect(verifySessionToken(token, "buyer", "unit-test-secret")).toBeNull();
  });
});
