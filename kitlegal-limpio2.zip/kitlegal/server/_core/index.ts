import "dotenv/config";
import compression from "compression";
import express from "express";
import { createServer } from "http";
import path from "node:path";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { publicPlatformScript } from "./publicConfig";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic } from "./vite";
import { registerKitAccessRoutes } from "./kitAccess";

async function startServer() {
  const app = express();
  const server = createServer(app);
  const projectRoot = path.resolve(import.meta.dirname, "../..");
  const portalDir =
    process.env.NODE_ENV === "production"
      ? path.resolve(import.meta.dirname, "portal")
      : projectRoot;
  const privateDownloadsDir =
    process.env.NODE_ENV === "production"
      ? path.resolve(import.meta.dirname, "private-downloads")
      : path.join(projectRoot, "descargas");
  const assetCache = {
    maxAge: process.env.NODE_ENV === "production" ? "1y" : 0,
    immutable: process.env.NODE_ENV === "production",
  };
  app.set("trust proxy", 1);
  app.disable("x-powered-by");
  if (
    process.env.NODE_ENV === "production" &&
    (!process.env.KIT_ACCESS_SECRET ||
      process.env.KIT_ACCESS_SECRET.length < 32 ||
      process.env.KIT_ACCESS_SECRET.startsWith("replace-with-"))
  ) {
    throw new Error("KIT_ACCESS_SECRET must be a random value of at least 32 characters in production");
  }
  app.use((req, res, next) => {
    const forwardedProto = req
      .get("x-forwarded-proto")
      ?.split(",", 1)[0]
      ?.trim()
      .toLowerCase();
    const isHttps = forwardedProto === "https" || req.protocol === "https";
    res.set({
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "strict-origin-when-cross-origin",
      "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
      "Cross-Origin-Opener-Policy": "same-origin-allow-popups",
      "Cross-Origin-Resource-Policy": "same-site",
      "Content-Security-Policy":
        "default-src 'self'; base-uri 'self'; object-src 'none'; form-action 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; script-src 'self'; connect-src 'self'",
    });
    if (isHttps) {
      res.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
    }
    next();
  });
  app.use(compression());
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
  // SEO público: solo la página comercial de acceso es indexable; el portal y las APIs son privados.
  app.get("/robots.txt", (_req, res) => {
    res.type("text/plain").send(`User-agent: *\nAllow: /acceso\nDisallow: /\nDisallow: /api/\nDisallow: /admin\nSitemap: https://kitlegalugc-whed455u.manus.space/sitemap.xml\n`);
  });
  app.get("/sitemap.xml", (_req, res) => {
    res.type("application/xml").send(`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>https://kitlegalugc-whed455u.manus.space/acceso</loc><changefreq>monthly</changefreq><priority>1.0</priority></url></urlset>`);
  });
  app.get("/api/platform/config.js", (_req, res) => {
    res.set("Cache-Control", "no-store").type("application/javascript").send(publicPlatformScript());
  });
  // Stable aliases for editorial assets. The package stores these files below
  // /public; older markup uses /images and /fonts. Without these explicit
  // routes, the SPA fallback can return index.html with HTTP 200 for an asset.
  app.use(
    "/images",
    express.static(path.join(portalDir, "public/images"), assetCache)
  );
  app.use(
    "/fonts",
    express.static(path.join(portalDir, "public/fonts"), assetCache)
  );
  app.get("/favicon.svg", (_req, res) => res.sendFile(path.join(portalDir, "public/favicon.svg")));
  registerKitAccessRoutes(app, { portalDir, privateDownloadsDir });
  registerOAuthRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // The product is the editorial portal at the project root. Serve the same
  // portal in development and production so Preview matches the published site.
  serveStatic(app, portalDir);

  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  server.listen(port, "0.0.0.0", () => console.log(`Server listening on port ${port}`));
}

startServer().catch(error => { console.error(error); process.exit(1); });
