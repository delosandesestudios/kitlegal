import express, { type Express } from "express";
import fs from "fs";
import path from "path";

export function serveStatic(app: Express, portalDir: string) {
  const distPath = portalDir;
  if (!fs.existsSync(distPath)) {
    console.error(
      `Could not find the portal directory: ${distPath}, make sure the portal has been packaged`
    );
  }

  app.use(express.static(distPath));

  // fall through to index.html if the file doesn't exist
  app.use("*", (_req, res) => {
    res.sendFile(path.resolve(distPath, "index.html"));
  });
}
