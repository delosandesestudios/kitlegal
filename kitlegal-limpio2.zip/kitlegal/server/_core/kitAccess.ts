import crypto from "node:crypto";
import express from "express";
import fs from "node:fs";
import path from "node:path";
import type { Express, NextFunction, Request, Response } from "express";
import {
  createAccessToken,
  createSessionToken,
  hashAccessCode,
  KIT_ACCESS_COOKIE,
  KIT_ADMIN_COOKIE,
  normalizeEmail,
  readCookieValue,
  verifyAccessCode,
  verifySession,
  verifySessionToken,
} from "./access";
import {
  createKitBuyer,
  getKitBuyerByEmail,
  listKitBuyers,
  updateKitBuyer,
} from "../db";

const MAX_LOGIN_FAILURES = 5;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const loginAttempts = new Map<string, { count: number; expiresAt: number }>();
let ephemeralDevelopmentSecret: string | undefined;

type KitAccessOptions = {
  portalDir: string;
  privateDownloadsDir: string;
};

function signingSecret() {
  const secret = process.env.KIT_ACCESS_SECRET?.trim();
  if (secret && !secret.startsWith("replace-with-")) {
    if (secret.length < 32) {
      throw new Error("KIT_ACCESS_SECRET must be at least 32 characters in production");
    }
    return secret;
  }
  if (process.env.NODE_ENV === "production") {
    throw new Error("KIT_ACCESS_SECRET must be configured in production");
  }
  // Nunca usamos un fallback predecible cuando el preview tiene base de datos.
  // En producción siempre debe existir un secreto persistente configurado.
  ephemeralDevelopmentSecret ??= crypto.randomBytes(32).toString("base64url");
  return ephemeralDevelopmentSecret;
}

function cookieOptions(req: Request) {
  const forwardedProto = req
    .get("x-forwarded-proto")
    ?.split(",", 1)[0]
    ?.trim()
    .toLowerCase();
  const originProtocol = (() => {
    try {
      return req.get("origin") ? new URL(req.get("origin")!).protocol : "";
    } catch {
      return "";
    }
  })();
  const isPublicHttps =
    forwardedProto === "https" ||
    req.protocol === "https" ||
    originProtocol === "https:";
  return {
    httpOnly: true,
    path: "/",
    // Preview and the published site can be embedded/cross-site over HTTPS.
    sameSite: isPublicHttps ? ("none" as const) : ("lax" as const),
    secure: isPublicHttps,
    maxAge: 1000 * 60 * 60 * 8,
  };
}

function validEmail(value: unknown): value is string {
  return typeof value === "string" && normalizeEmail(value) !== undefined;
}

function localDevBuyerBypassEnabled() {
  return (
    process.env.NODE_ENV === "development" &&
    (!process.env.DATABASE_URL || !process.env.KIT_ACCESS_SECRET)
  );
}

function safeEqual(left: string, right: string) {
  const leftBuffer = Buffer.from(left);
  const rightBuffer = Buffer.from(right);
  return (
    leftBuffer.length === rightBuffer.length &&
    crypto.timingSafeEqual(leftBuffer, rightBuffer)
  );
}

function isAdminConfigured() {
  const email = process.env.KIT_ADMIN_EMAIL?.trim() ?? "";
  const password = process.env.KIT_ADMIN_PASSWORD ?? "";
  return Boolean(
    validEmail(email) &&
      password.length >= 12 &&
      !password.startsWith("replace-with-")
  );
}

function adminEmail() {
  return process.env.KIT_ADMIN_EMAIL?.trim().toLowerCase() ?? "";
}

function adminSession(req: Request) {
  return verifySessionToken(
    readCookieValue(req.headers.cookie, KIT_ADMIN_COOKIE),
    "admin",
    signingSecret()
  );
}

function buyerSession(req: Request) {
  return verifySession(
    readCookieValue(req.headers.cookie, KIT_ACCESS_COOKIE),
    "buyer",
    signingSecret()
  );
}

function respondError(res: Response, error: unknown, message: string) {
  console.error(`[Kit access] ${message}`, error);
  if (error instanceof Error && error.message === "Database is not available") {
    res.status(503).json({
      ok: false,
      message: "El acceso aún no está configurado. Contacta a la administradora.",
    });
    return;
  }
  res.status(500).json({ ok: false, message });
}

async function requireBuyer(req: Request, res: Response, next: NextFunction) {
  try {
    const session = buyerSession(req);
    if (!session) {
      res.status(401).json({ ok: false, message: "Inicia sesión para descargar." });
      return;
    }

    if (localDevBuyerBypassEnabled()) {
      next();
      return;
    }

    const buyer = await getKitBuyerByEmail(session.email);
    if (!buyer?.active || buyer.accessVersion !== session.accessVersion) {
      res.clearCookie(KIT_ACCESS_COOKIE, cookieOptions(req));
      res.status(401).json({ ok: false, message: "Este acceso ya no está activo." });
      return;
    }

    next();
  } catch (error) {
    respondError(res, error, "No se pudo comprobar el acceso del comprador.");
  }
}

async function requirePortal(req: Request, res: Response, next: NextFunction) {
  try {
    const session = buyerSession(req);
    if (!session) {
      res.redirect(303, "/acceso");
      return;
    }

    if (localDevBuyerBypassEnabled()) {
      next();
      return;
    }

    const buyer = await getKitBuyerByEmail(session.email);
    if (!buyer?.active || buyer.accessVersion !== session.accessVersion) {
      res.clearCookie(KIT_ACCESS_COOKIE, cookieOptions(req));
      res.redirect(303, "/acceso");
      return;
    }
    next();
  } catch (error) {
    respondError(res, error, "No se pudo comprobar la sesión del portal.");
  }
}

async function requireAdmin(req: Request, res: Response, next: NextFunction) {
  try {
    if (!adminSession(req)) {
      res.status(401).json({ ok: false, message: "Inicia sesión como administradora." });
      return;
    }
    next();
  } catch (error) {
    respondError(res, error, "No se pudo comprobar la sesión de administración.");
  }
}

function rateLimitKey(ip: string, scope: string) {
  return `${ip}|${scope}`;
}

function trackLoginFailure(key: string) {
  const now = Date.now();
  const current = loginAttempts.get(key);
  if (!current || current.expiresAt <= now) {
    loginAttempts.set(key, { count: 1, expiresAt: now + LOGIN_WINDOW_MS });
    return;
  }
  current.count += 1;
}

function clearLoginFailures(key: string) {
  loginAttempts.delete(key);
}

function isRateLimited(key: string) {
  const attempts = loginAttempts.get(key);
  if (!attempts) return false;
  if (attempts.expiresAt <= Date.now()) {
    loginAttempts.delete(key);
    return false;
  }
  return attempts.count >= MAX_LOGIN_FAILURES;
}

function requestHost(req: Request) {
  return (
    req
      .get("x-forwarded-host")
      ?.split(",", 1)[0]
      ?.trim() || req.get("host") || ""
  );
}

function requireSameOrigin(req: Request, res: Response, next: NextFunction) {
  const origin = req.get("origin");
  try {
    const originUrl = origin ? new URL(origin) : null;
    const forwardedProto = req
      .get("x-forwarded-proto")
      ?.split(",", 1)[0]
      ?.trim()
      .toLowerCase();
    const expectedProtocol = forwardedProto || req.protocol;
    const fetchSite = req.get("sec-fetch-site");
    const browserConfirmedSameOrigin =
      fetchSite === "same-origin" || fetchSite === "none";
    const originHostMatches = originUrl?.host === requestHost(req);
    if (
      !originUrl ||
      (!browserConfirmedSameOrigin &&
        (!originHostMatches || originUrl.protocol !== `${expectedProtocol}:`))
    ) {
      res.status(403).json({ ok: false, message: "Solicitud de origen no autorizado." });
      return;
    }
  } catch {
    res.status(403).json({ ok: false, message: "Solicitud de origen no autorizado." });
    return;
  }
  next();
}

export function registerKitAccessRoutes(app: Express, options: KitAccessOptions) {
  app.get("/api/kit-access/status", async (req, res) => {
    try {
      const session = buyerSession(req);
      if (!session) {
        res.json({ ok: false, email: null });
        return;
      }

      if (localDevBuyerBypassEnabled()) {
        res.json({ ok: true, email: session.email });
        return;
      }

      const buyer = await getKitBuyerByEmail(session.email);
      if (!buyer?.active || buyer.accessVersion !== session.accessVersion) {
        res.clearCookie(KIT_ACCESS_COOKIE, cookieOptions(req));
        res.json({ ok: false, email: null });
        return;
      }
      res.json({ ok: true, email: buyer.email });
    } catch (error) {
      if (localDevBuyerBypassEnabled()) {
        const session = buyerSession(req);
        res.json({ ok: Boolean(session), email: session?.email ?? null });
        return;
      }
      respondError(res, error, "No se pudo consultar el estado del acceso.");
    }
  });

  app.post("/api/kit-access/validate", requireSameOrigin, async (req, res) => {
    const ip = req.ip ?? "unknown";
    const email = validEmail(req.body?.email)
      ? normalizeEmail(req.body.email) ?? ""
      : "";
    const code = typeof req.body?.code === "string" ? req.body.code.trim() : "";
    // Evita bloquear a todas las creadoras detrás de una misma red compartida.
    const attemptKey = rateLimitKey(ip, email || "unknown");
    if (isRateLimited(attemptKey)) {
      res.set("Retry-After", String(Math.ceil(LOGIN_WINDOW_MS / 1000))).status(429).json({
        ok: false,
        message: "Demasiados intentos para este correo. Espera unos minutos y vuelve a intentarlo.",
      });
      return;
    }

    if (localDevBuyerBypassEnabled()) {
      if (!email || email.length > 320) {
        res.status(401).json({
          ok: false,
          message: "Introduce un correo válido para entrar al kit.",
        });
        return;
      }
      const token = createAccessToken(email, signingSecret(), 1);
      res.cookie(KIT_ACCESS_COOKIE, token, cookieOptions(req));
      res.set("Cache-Control", "no-store").json({ ok: true, email });
      return;
    }

    if (!email || !code || code.length > 256) {
      res.status(401).json({
        ok: false,
        message: "El correo o el código no coinciden con un acceso activo.",
      });
      return;
    }

    try {
      const buyer = await getKitBuyerByEmail(email);
      if (!buyer?.active || !verifyAccessCode(code, buyer.codeHash)) {
        trackLoginFailure(attemptKey);
        res.status(401).json({
          ok: false,
          message: "El correo o el código no coinciden con un acceso activo.",
        });
        return;
      }

      clearLoginFailures(attemptKey);
      const token = createAccessToken(
        buyer.email,
        signingSecret(),
        buyer.accessVersion
      );
      res.cookie(KIT_ACCESS_COOKIE, token, cookieOptions(req));
      res.set("Cache-Control", "no-store").json({ ok: true, email: buyer.email });
    } catch (error) {
      respondError(res, error, "No se pudo validar el acceso.");
    }
  });

  app.post("/api/kit-access/logout", requireSameOrigin, (req, res) => {
    res.clearCookie(KIT_ACCESS_COOKIE, cookieOptions(req));
    res.json({ ok: true });
  });

  app.get("/api/kit-access/admin/session", (req, res) => {
    try {
      res.json({ ok: Boolean(adminSession(req)) });
    } catch (error) {
      respondError(res, error, "No se pudo consultar la sesión administrativa.");
    }
  });

  app.post("/api/kit-access/admin/login", requireSameOrigin, (req, res) => {
    const email = normalizeEmail(req.body?.email) ?? "";
    const password = typeof req.body?.password === "string" ? req.body.password : "";
    const ip = req.ip ?? "unknown";
    const adminAttemptKey = rateLimitKey(ip, "admin");
    if (isRateLimited(adminAttemptKey)) {
      res.set("Retry-After", String(Math.ceil(LOGIN_WINDOW_MS / 1000))).status(429).json({
        ok: false,
        message: "Demasiados intentos. Espera unos minutos y vuelve a intentarlo.",
      });
      return;
    }

    if (!isAdminConfigured()) {
      res.status(503).json({
        ok: false,
        message: "La administradora debe configurar KIT_ADMIN_EMAIL y una contraseña segura en el servidor.",
      });
      return;
    }

    if (!safeEqual(email, adminEmail()) || !safeEqual(password, process.env.KIT_ADMIN_PASSWORD!)) {
      trackLoginFailure(adminAttemptKey);
      res.status(401).json({ ok: false, message: "Credenciales administrativas incorrectas." });
      return;
    }

    clearLoginFailures(adminAttemptKey);
    try {
      const token = createSessionToken(email, "admin", signingSecret());
      res.cookie(KIT_ADMIN_COOKIE, token, cookieOptions(req));
      res.set("Cache-Control", "no-store").json({ ok: true });
    } catch (error) {
      respondError(res, error, "No se pudo iniciar la sesión administrativa.");
    }
  });

  app.post("/api/kit-access/admin/logout", requireSameOrigin, (req, res) => {
    res.clearCookie(KIT_ADMIN_COOKIE, cookieOptions(req));
    res.json({ ok: true });
  });

  app.get("/api/kit-access/admin/buyers", requireAdmin, async (_req, res) => {
    try {
      const buyers = await listKitBuyers();
      res.set("Cache-Control", "no-store").json(buyers);
    } catch (error) {
      respondError(res, error, "No se pudo cargar la lista de compradores.");
    }
  });

  app.post("/api/kit-access/admin/buyers", requireSameOrigin, requireAdmin, async (req, res) => {
    const email = validEmail(req.body?.email)
      ? normalizeEmail(req.body.email) ?? ""
      : "";
    const code = typeof req.body?.code === "string" ? req.body.code.trim() : "";
    if (!email || code.length < 6 || code.length > 256) {
      res.status(400).json({
        ok: false,
        message: "Introduce un correo válido y una clave de al menos 6 caracteres.",
      });
      return;
    }

    try {
      if (await getKitBuyerByEmail(email)) {
        res.status(409).json({ ok: false, message: "Ya existe un acceso para ese correo." });
        return;
      }
      await createKitBuyer(email, hashAccessCode(code));
      res.status(201).set("Cache-Control", "no-store").json({ ok: true, email });
    } catch (error) {
      respondError(res, error, "No se pudo crear el acceso.");
    }
  });

  app.patch("/api/kit-access/admin/buyers/:email", requireSameOrigin, requireAdmin, async (req, res) => {
    const email = validEmail(req.params.email)
      ? normalizeEmail(req.params.email) ?? ""
      : "";
    const changes: { active?: boolean; codeHash?: string } = {};
    if (typeof req.body?.active === "boolean") changes.active = req.body.active;
    if (typeof req.body?.code === "string") {
      const code = req.body.code.trim();
      if (code.length < 6 || code.length > 256) {
        res.status(400).json({
          ok: false,
          message: "La nueva clave debe tener entre 6 y 256 caracteres.",
        });
        return;
      }
      changes.codeHash = hashAccessCode(code);
    }
    if (!email || Object.keys(changes).length === 0) {
      res.status(400).json({ ok: false, message: "No hay cambios válidos para guardar." });
      return;
    }

    try {
      const buyer = await updateKitBuyer(email, changes);
      if (!buyer) {
        res.status(404).json({ ok: false, message: "No encontramos ese comprador." });
        return;
      }
      res.set("Cache-Control", "no-store").json({
        ok: true,
        buyer: { email: buyer.email, active: buyer.active },
      });
    } catch (error) {
      respondError(res, error, "No se pudo actualizar el acceso.");
    }
  });

  app.get("/api/kit-access/files/:filename", requireBuyer, (req, res) => {
    const filename = req.params.filename;
    if (
      path.basename(filename) !== filename ||
      !/^[\w.-]+\.(?:docx|md|pdf|zip)$/i.test(filename)
    ) {
      res.status(404).end("Not Found");
      return;
    }

    const filePath = path.join(options.privateDownloadsDir, filename);
    if (!fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) {
      res.status(404).end("Not Found");
      return;
    }

    res.set({
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
    });
    res.download(filePath, filename, error => {
      if (error && !res.headersSent) {
        console.error("[Kit access] Could not serve a protected download", error);
        res.status(500).end("Could not serve this download");
      }
    });
  });

  app.use("/descargas", (_req, res) => {
    res.status(404).end("Not Found");
  });

  app.get("/admin", (_req, res) => {
    res.sendFile(path.join(options.portalDir, "admin.html"));
  });
  app.get("/acceso", (_req, res) => {
    res.sendFile(path.join(options.portalDir, "access.html"));
  });
  app.get(["/", "/index.html"], requirePortal, (_req, res) => {
    res.sendFile(path.join(options.portalDir, "index.html"));
  });
  for (const asset of ["styles.css", "script.js", "access.js", "admin.js"]) {
    app.get(`/${asset}`, (_req, res) => {
      res.set(
        "Cache-Control",
        process.env.NODE_ENV === "production"
          ? "public, max-age=31536000, immutable"
          : "no-cache"
      );
      res.sendFile(path.join(options.portalDir, asset));
    });
  }
  app.use(
    "/public",
    express.static(path.join(options.portalDir, "public"), {
      maxAge: process.env.NODE_ENV === "production" ? "1y" : 0,
      immutable: process.env.NODE_ENV === "production",
      dotfiles: "deny",
      index: false,
    })
  );
}
