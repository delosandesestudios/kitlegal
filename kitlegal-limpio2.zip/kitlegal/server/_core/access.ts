import crypto from "node:crypto";

export const KIT_ACCESS_COOKIE = "kit_ugc_access";
export const KIT_ADMIN_COOKIE = "kit_ugc_admin";
const SESSION_LIFETIME_SECONDS = 60 * 60 * 8;

export function normalizeEmail(value: string | undefined | null) {
  if (typeof value !== "string") return undefined;

  const normalized = value.trim().toLowerCase();
  if (
    normalized.length === 0 ||
    normalized.length > 320 ||
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized)
  ) {
    return undefined;
  }

  return normalized;
}

function getSigningSecret(secret?: string) {
  const configuredSecret = secret ?? process.env.KIT_ACCESS_SECRET;
  if (configuredSecret) return configuredSecret;
  if (process.env.NODE_ENV === "production") {
    throw new Error("KIT_ACCESS_SECRET must be configured in production");
  }
  return "kit-legal-local-development-only-secret";
}

export function hashAccessCode(code: string) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(code, salt, 64);
  return `scrypt:${salt.toString("base64url")}:${hash.toString("base64url")}`;
}

export function verifyAccessCode(code: string, storedHash: string) {
  const [algorithm, saltValue, hashValue] = storedHash.split(":");
  if (algorithm !== "scrypt" || !saltValue || !hashValue) return false;

  try {
    const salt = Buffer.from(saltValue, "base64url");
    const expectedHash = Buffer.from(hashValue, "base64url");
    if (salt.length !== 16 || expectedHash.length !== 64) return false;
    const actualHash = crypto.scryptSync(code, salt, expectedHash.length);
    return crypto.timingSafeEqual(actualHash, expectedHash);
  } catch {
    return false;
  }
}

export function readCookieValue(
  cookieHeader: string | undefined,
  cookieName: string
): string | undefined {
  if (!cookieHeader) return undefined;

  for (const part of cookieHeader.split(";")) {
    const [name, ...rest] = part.trim().split("=");
    if (!name || name !== cookieName) continue;
    try {
      return decodeURIComponent(rest.join("=") || "");
    } catch {
      return undefined;
    }
  }

  return undefined;
}

type SessionPurpose = "buyer" | "admin";
export type VerifiedSession = { email: string; accessVersion?: number };

export function createSessionToken(
  email: string,
  purpose: SessionPurpose,
  secret?: string,
  accessVersion?: number
) {
  const issuedAt = Math.floor(Date.now() / 1000);
  const payload = Buffer.from(
    JSON.stringify({
      email: email.toLowerCase(),
      purpose,
      issuedAt,
      expiresAt: issuedAt + SESSION_LIFETIME_SECONDS,
      ...(purpose === "buyer" ? { accessVersion } : {}),
    })
  ).toString("base64url");
  const signature = crypto
    .createHmac("sha256", getSigningSecret(secret))
    .update(payload)
    .digest("base64url");
  return `${payload}.${signature}`;
}

export function verifySession(
  token: string | undefined,
  purpose: SessionPurpose,
  secret?: string
): VerifiedSession | null {
  if (!token) return null;

  const [payload, signature] = token.split(".");
  if (!payload || !signature) return null;

  try {
    const expectedSignature = crypto
      .createHmac("sha256", getSigningSecret(secret))
      .update(payload)
      .digest();
    const providedSignature = Buffer.from(signature, "base64url");
    if (
      expectedSignature.length !== providedSignature.length ||
      !crypto.timingSafeEqual(expectedSignature, providedSignature)
    ) {
      return null;
    }

    const parsed = JSON.parse(
      Buffer.from(payload, "base64url").toString("utf8")
    ) as {
      email?: string;
      purpose?: SessionPurpose;
      issuedAt?: number;
      expiresAt?: number;
      accessVersion?: number;
    };
    const now = Math.floor(Date.now() / 1000);
    if (
      typeof parsed.email !== "string" ||
      parsed.purpose !== purpose ||
      !Number.isInteger(parsed.issuedAt) ||
      !Number.isInteger(parsed.expiresAt) ||
      parsed.issuedAt! > now ||
      parsed.expiresAt! <= now ||
      (purpose === "buyer" &&
        (!Number.isInteger(parsed.accessVersion) || parsed.accessVersion! < 1))
    ) {
      return null;
    }

    return {
      email: parsed.email.toLowerCase(),
      ...(purpose === "buyer" ? { accessVersion: parsed.accessVersion } : {}),
    };
  } catch {
    return null;
  }
}

export function verifySessionToken(
  token: string | undefined,
  purpose: SessionPurpose,
  secret?: string
) {
  return verifySession(token, purpose, secret)?.email ?? null;
}

export function createAccessToken(
  email: string,
  secret?: string,
  accessVersion = 1
) {
  return createSessionToken(email, "buyer", secret, accessVersion);
}

export function verifyAccessToken(
  token: string | undefined,
  secret?: string
) {
  return verifySession(token, "buyer", secret)?.email ?? null;
}
