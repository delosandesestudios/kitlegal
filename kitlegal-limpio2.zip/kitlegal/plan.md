# Plan de mejora — Kit Legal UGC

## Alcance

Pulir la landing existente de Kit Legal UGC sin cambiar su arquitectura funcional ni su dirección editorial. La intervención aumenta la presencia de los emojis del encabezado, corrige y unifica la redacción en español, consolida la experiencia móvil de los mensajes tipo iMessage y de los elementos flotantes, y reduce el coste de carga y de animación para superar 90 en Lighthouse Performance.

## Dirección de diseño aprobada

- **Movimiento:** editorial contemporáneo pastel con *soft brutalism*; se conserva la composición, el ritmo y la personalidad del sitio.
- **Principios:** jerarquía inmediata, calidez profesional, acciones inequívocas y legibilidad sin esfuerzo.
- **Color:** se mantiene la paleta pastel como capa emocional y la tinta oscura como ancla de contraste y orientación.
- **Estructura:** recorrido narrativo por etapas de colaboración, apoyado por burbujas de mensaje y una ruta secuencial en lugar de una cuadrícula centralizada.
- **Elementos distintivos:** emojis de mayor escala en el encabezado, burbujas tipo iMessage entrantes y stickers editoriales en profundidad.
- **Interacción:** los mensajes, controles de descarga y CTA conservan señales claras de acción; en móvil se priorizan zonas táctiles, lectura y ausencia de solapamientos.
- **Animación:** transformaciones compuestas y pausables, con amplitud y cantidad reducidas en móviles; todas respetan `prefers-reduced-motion` y no bloquean el contenido.
- **Tipografía:** titulares serif de alto contraste y cuerpo Inter para lectura funcional; se conservan las proporciones y los saltos de línea editoriales.
- **Esencia de marca:** herramientas legales claras para que creadoras UGC negocien con criterio y confianza. Personalidad: cercana, profesional y empoderadora.
- **Voz:** español venezolano neutro, directo y cuidadoso. Ejemplos: “Define el alcance antes de empezar.” / “Tu trabajo creativo también necesita condiciones claras.”
- **Marca y color propio:** se preserva el wordmark tipográfico existente y el rosa `--rose` como firma visual.

## Implementación

- `index.html`: actualizar microcopy, metadatos y atributos de las imágenes; conservar rutas y semántica.
- `script.js`: ajustar mensajes de interfaz y limitar trabajo de animación/observación a los escenarios que lo necesitan.
- `styles.css`: unificar las últimas reglas activas, ampliar los emojis del encabezado de forma responsiva, reforzar los componentes tipo iMessage y aplicar reglas móviles que eliminen cortes, desbordamientos y colisiones.
- `public/images/personality/`: reemplazar los PNG usados por sus equivalentes WebP, mantener dimensiones explícitas y suprimir recursos duplicados no usados.
- `scripts/`: añadir una comprobación local de presupuesto de recursos y Lighthouse para documentar la optimización sin introducir dependencias en producción.
- `manus-routes.json`: mantener la única ruta pública de la landing.

## Rendimiento

- Servir imágenes locales en WebP, con `width`, `height`, `loading="lazy"` y `decoding="async"` fuera del primer contenido visible.
- Mantener los recursos de cabecera críticos con prioridad adecuada y diferir las imágenes decorativas no críticas.
- Limitar las animaciones a `transform` y `opacity`, reducir su intensidad en pantallas táctiles y no aplicar `will-change` de forma permanente a múltiples elementos.
- Evitar dependencias y peticiones nuevas; mantener CSS y JavaScript nativos para conservar un bundle pequeño.
- Validar rendimiento en vista móvil y escritorio con Lighthouse y corregir bloqueos concretos hasta superar 90 en Performance.

## Estructura del proyecto

- `index.html`, `styles.css`, `script.js`: landing pública estática y sus interacciones.
- `public/`: favicon, manifiesto de rutas y recursos visuales públicos.
- `descargas/`: materiales privados consumidos por las rutas de acceso.
- `server/`, `drizzle/`: acceso, sesiones y entrega protegida del kit; el servidor entrega texto comprimido, aplica caché prolongada a recursos estáticos en producción y permite una sesión de prueba solo en desarrollo sin secreto configurado.
- `scripts/`: empaquetado del portal y comprobaciones de calidad de rendimiento.
