# TODO — Mejora de landing Kit Legal UGC

- [x] **Aumentar los emojis del header sin alterar su composición:** aumentar el tamaño de los emojis del header conservando su estilo y composición actuales, con escala segura en desktop, tablet y móvil.
- [x] **Corregir y humanizar la redacción:** revisar todos los textos visibles y de interfaz de la landing en español; usar una voz directa, cercana y clara, como si se hablara con una amiga creadora. Incluir la introducción internacional «Si te busca una marca de afuera…» y la sección «Cuándo pedirme una asesoría 1:1» con el texto de acompañamiento acordado.
- [x] **Simplificar la Base 01:** en el modal, mostrar el texto «Ese momento en el que la marca te escribe…», las cuatro preguntas acordadas, el consejo «Primero entiende bien la oportunidad…» y la instrucción para abrir la vista previa, descargar, duplicar y completar los corchetes antes de enviar al cliente.
- [x] **Hacer sólidos los componentes tipo iMessage en móvil:** evitar cortes, desbordamientos o problemas de legibilidad en las burbujas de mensaje nuevas y mantener tamaños táctiles y espaciados correctos a 390 px de ancho.
- [x] **Adaptar las animaciones y acciones flotantes a pantallas móviles:** conservar una sensación fluida, evitar solapamientos con el contenido, organizar las acciones en una fila compacta y respetar `prefers-reduced-motion`.
- [x] **Reducir el coste de recursos:** usar WebP para recursos visuales, eliminar PNG duplicados, añadir `decoding="async"` y prioridades adecuadas, comprimir HTTP, cachear estáticos en producción y minificar CSS/JS en el empaquetado.
- [x] **Superar 90 en Lighthouse Performance:** optimizar carga y ejecución del frontend manteniendo la experiencia visual; Lighthouse móvil autenticado: **93/100**.
