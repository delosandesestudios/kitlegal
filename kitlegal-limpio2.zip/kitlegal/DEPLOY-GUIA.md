# Guía de despliegue — Kit Legal UGC

## 1. Subir a GitHub
1. Crea un repositorio privado llamado `kit-legal` (privado = tus documentos y código no son públicos).
2. En tu computadora, dentro de la carpeta del proyecto:
   git init
   git add .
   git commit -m "Kit Legal listo para lanzamiento"
   git branch -M main
   git remote add origin https://github.com/TU-USUARIO/kit-legal.git
   git push -u origin main
   (Reemplaza TU-USUARIO por tu usuario de GitHub. GitHub te pedirá iniciar sesión.)

## 2. La base de datos (MySQL)
Vercel NO incluye base de datos. Opciones gratuitas de MySQL:
- TiDB Cloud (tidbcloud.com) — plan gratuito, compatible MySQL.
- Aiven (aiven.io) — plan gratuito MySQL.
Crea la base, copia la cadena de conexión y úsala como DATABASE_URL.

## 3. Variables de entorno (en Vercel, nunca en el código)
DATABASE_URL=mysql://USUARIO:CLAVE@HOST:3306/NOMBRE_BD
KIT_ACCESS_SECRET=(32+ caracteres aleatorios; genera uno en https://www.random.org/strings/ o con un generador de contraseñas)
KIT_ADMIN_EMAIL=tu-correo-de-admin
KIT_ADMIN_PASSWORD=(contraseña nueva y única — NO reutilices una que hayas compartido por chat)

## 4. Opción Vercel (requiere adaptación)
Vercel está pensado para funciones sin servidor; este proyecto usa un servidor Express de larga duración. Funciona, pero hay que adaptar el arranque. Si quieres lanzar HOY, la opción más simple:

## 5. Opción recomendada para lanzar hoy: Railway o Render
1. Railway.app o Render.com → "New project" → conecta tu GitHub → elige el repo `kit-legal`.
2. Agrega el plugin/base de datos MySQL dentro de la misma plataforma (Railway lo incluye con un clic).
3. Pega las 4 variables de entorno del paso 3.
4. Comando de build: `pnpm install && pnpm build` — Comando de inicio: `pnpm start`.
5. Railway/Render te da una URL pública (ej: kitlegal.up.railway.app). Esa es la que entregas a las creadoras.

## 6. Después del primer despliegue
1. `pnpm db:migrate` crea las tablas (en Railway puedes agregarlo al comando de inicio la primera vez).
2. Entra a /admin con tu correo y contraseña de admin.
3. Crea la cuenta de cada compradora con su código de acceso.
4. Cuando alguien compre en Beacons, créale su acceso y envíale: URL del sitio + /acceso + correo + código.

## Notas de seguridad
- Nunca subas el archivo .env a GitHub (ya está en .gitignore).
- Cambia la contraseña de admin si la escribiste en algún chat o nota.
- Los secretos viven solo en las variables de entorno de la plataforma.
