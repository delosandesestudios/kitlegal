
# Kit Legal UGC

El portal editorial de la raíz (`index.html`, `styles.css`, `script.js`) es la interfaz oficial. Express sirve esa misma interfaz en desarrollo y producción. La aplicación React de `client/` permanece como una base técnica aparte; no es la experiencia publicada del kit.

## Guía de bienvenida para compradoras

Al descomprimir el paquete de documentos, abre primero `00-LEEME-ANTES-DE-ABRIR.md`. En Base 02, la creadora debe elegir una sola vía para confirmar el acuerdo: la hoja interna `02-confirmacion-antes-de-grabar.md`, la versión Word formal `02-confirmacion-de-acuerdos.docx` o la confirmación express `02-confirmacion-acuerdos-completa.md`. No deben usarse como tres pasos obligatorios ni como documentos equivalentes.

La hoja Markdown es un control interno para preparar la colaboración antes de grabar. El Word es la versión formal editable que puede enviarse a la marca. La express sirve para obtener un “Acepto estos términos” por WhatsApp, correo o DM. La guía explica también el significado de los colores: amarillo para campos editables, rosa para instrucciones, coral para límites, verde para confirmaciones y gris para contenido interno que debe borrarse.

## Ruta recomendada

1. Base 01: aceptar y negociar.
2. Base 02: confirmar antes de grabar.
3. Base 03: revisar antes de entregar.
4. Base 04: autorizar anuncios y Paid Media.
5. Base 05: actuar ante pagos pendientes o incumplimientos.

## Desarrollo y publicación

- Copia `.env.example` a `.env` y configura `DATABASE_URL`, `KIT_ACCESS_SECRET`, `KIT_ADMIN_EMAIL` y `KIT_ADMIN_PASSWORD`.
- `corepack pnpm db:migrate`: crea las tablas, incluida la lista persistente de compradoras.
- `corepack pnpm dev`: inicia el portal y API en modo desarrollo.
- `corepack pnpm check` y `corepack pnpm test`: tipos y pruebas.
- `corepack pnpm build` y `corepack pnpm start`: genera y sirve el portal en producción.
- `PORT` determina el puerto; el predeterminado es 3000.

Los documentos se empaquetan en `dist/private-downloads`, fuera de la carpeta pública. Las rutas de descarga comprueban una sesión válida y que la cuenta siga activa. No publiques un build estático separado para vender acceso: no ejecutaría las verificaciones del servidor.

## Administración y acceso de compradoras

- `/admin`: panel privado para crear una cuenta, revocar/reactivar el acceso y asignar una clave nueva.
- `/acceso`: pantalla de inicio de sesión de las compradoras.
- Las claves de compradoras se almacenan con hash scrypt; el panel nunca las lista en texto legible.
- La sesión usa una cookie firmada HttpOnly. Cada acceso al portal y descarga vuelve a comprobar que la compradora esté activa.
- La contraseña administrativa y el secreto de firma deben ser únicos, aleatorios y configurados solo en el entorno del servidor. No uses los valores de ejemplo en producción.
- `data/access-users.json` y el servidor estático de prueba ya no son parte del flujo de acceso.

`server/_core/publicConfig.ts` publica solo valores explícitamente permitidos. Las claves privadas permanecen del lado del servidor.
