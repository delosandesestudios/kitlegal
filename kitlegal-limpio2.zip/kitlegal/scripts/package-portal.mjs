import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { transformSync } from "esbuild";

const projectRoot = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  ".."
);
const portalOutput = path.join(projectRoot, "dist", "portal");
const downloadsOutput = path.join(projectRoot, "dist", "private-downloads");

function copyDirectory(source, destination) {
  fs.mkdirSync(destination, { recursive: true });
  for (const entry of fs.readdirSync(source, { withFileTypes: true })) {
    const sourcePath = path.join(source, entry.name);
    const destinationPath = path.join(destination, entry.name);
    if (entry.isDirectory()) {
      copyDirectory(sourcePath, destinationPath);
    } else if (entry.isFile()) {
      fs.copyFileSync(sourcePath, destinationPath);
    }
  }
}

for (const directory of [portalOutput, downloadsOutput]) {
  fs.rmSync(directory, { recursive: true, force: true });
}

fs.mkdirSync(portalOutput, { recursive: true });
for (const filename of [
  "index.html",
  "styles.css",
  "script.js",
  "admin.html",
  "admin.js",
  "access.html",
  "access.js",
]) {
  const source = fs.readFileSync(path.join(projectRoot, filename), "utf8");
  const loader = filename.endsWith(".css")
    ? "css"
    : filename.endsWith(".js")
      ? "js"
      : undefined;
  const output = loader
    ? transformSync(source, { loader, minify: true, target: "es2020" }).code
    : source;
  fs.writeFileSync(path.join(portalOutput, filename), output);
}
copyDirectory(
  path.join(projectRoot, "public"),
  path.join(portalOutput, "public")
);
copyDirectory(path.join(projectRoot, "descargas"), downloadsOutput);

console.log("Portal packaged; client documents remain outside the public web root.");
