import { spawn } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const projectRoot = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  ".."
);
const mode = process.argv[2] === "production" ? "production" : "development";
const command =
  mode === "production"
    ? ["dist/index.js"]
    : ["node_modules/tsx/dist/cli.mjs", "watch", "server/_core/index.ts"];
const child = spawn(process.execPath, command, {
  cwd: projectRoot,
  env: { ...process.env, NODE_ENV: mode },
  stdio: "inherit",
});

child.on("error", error => {
  console.error("Could not start the Kit Legal server:", error);
  process.exitCode = 1;
});
child.on("exit", (code, signal) => {
  if (signal) {
    process.kill(process.pid, signal);
    return;
  }
  process.exitCode = code ?? 1;
});
